/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

int main(void)
{
	uint16_t	times=0;
	HAL_Init();
	while(1)
	{
		
		for(times = 0; times < 4096; times +=455)
		{
			Set_Value(times);
			printf("DAC���õ�ѹ(mV)��%d\r\n", 3300*times/4095); 
			LED_Toggle();//��˸LED,��ʾϵͳ��������.
		  HAL_Delay(500);		
		}
		 for(times = 4095; times > 0; times -=455)
		{
			Set_Value(times);
			printf("DAC���õ�ѹ(mV)��%d\r\n", 3300*times/4095); 
			LED_Toggle();//��˸LED,��ʾϵͳ��������.
		  HAL_Delay(500);		
		}

	}
}
