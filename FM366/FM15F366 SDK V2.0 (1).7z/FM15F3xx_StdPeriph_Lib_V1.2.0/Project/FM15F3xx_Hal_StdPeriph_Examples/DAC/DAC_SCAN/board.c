/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin=GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}


DAC_HandleTypeDef DAC_Handler;
void DAC_Init(void)
{
	DAC_Handler.Instance = DAC0;
	
	DAC_Handler.Init.VrefSel = DAC_VREF_VDDA;
	DAC_Handler.Init.PowerMode = DAC_POWERMODE_HIGH;
	DAC_Handler.Init.WorkMode = DAC_WORKMODE_SWING;
	DAC_Handler.Init.TrigMode = DAC_TRIGMODE_SCAN;
	DAC_Handler.Init.ScanMode = DAC_SCANMODE_CONTINUE;
	DAC_Handler.Init.TrigSource = DAC_TRIGSRC_SOFTWARE;
	DAC_Handler.Init.ScanIntervalCnt = 0xFF;
	DAC_Handler.Init.TrigInvEn = DAC_TRIGINV_DISABLE;
	DAC_Handler.Init.TrigEdge = DAC_TRIGEDGE_HIGH;
	DAC_Handler.Init.TrigFilter = DAC_TRIGFILTER_NoFILTER;
	
	HAL_DAC_Init(&DAC_Handler);
	
	HAL_DAC_Start(&DAC_Handler);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	UART_Init(115200);
	DAC_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

void DAC_CONVERT(void)
{
	uint16_t value = 0, pointer;
	for(value = 4095 ,pointer = 0; value > 456; value -=455 ,pointer++)
	{
		HAL_DAC_SetValue(&DAC_Handler, pointer, value);
	}	
	__HAL_DAC_SOFTWARETRIG(&DAC_Handler);
}
