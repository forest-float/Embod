/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

int main(void)
{
	HAL_Init();
  printf("DAC_SCAN DEMO!");
	DAC_CONVERT();//����
	while(1)
	{		
		LED_Toggle();		
		HAL_Delay(1000);	
	}	
}
