/**
  ******************************************************************************
  * @file    Lcd.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-05-26
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#include "lcd.h" 
#include "font.h"
//////////////////////////////////////////////////////////////////////////////////	 
//2.8寸TFT液晶驱动	   ILI9341
//////////////////////////////////////////////////////////////////////////////////
//写寄存器函数
//regval:寄存器值
static void LCD_WR_REG(uint8_t regval)
{   
//	regval=regval;		//使用-O2优化的时候,必须插入的延时
	LCD->LCD_REG=regval;//写入要写的寄存器序号	 
}
//写LCD数据
//data:要写入的值
static void LCD_WR_DATA(uint8_t data)
{	 
//	data=data;			//使用-O2优化的时候,必须插入的延时
	LCD->LCD_RAM=data;		 
}   
//开始写GRAM
static void LCD_WriteRAM_Prepare(void)
{
	LCD_WR_REG(0x2C);	  
}

/*********************************************************************************************************
** 函数名称:	LCD_Init
** 函数功能:	初始化lcd
** 输入参数:
** 输出参数:	无
** 返回值:		无
** 备注：
*********************************************************************************************************/
void LCD_Init(void)
{
	//9341初始化	 
	LCD_WR_REG(0xCF);  
	LCD_WR_DATA(0x00);
	LCD_WR_DATA(0xD9); 
	LCD_WR_DATA(0X30);

	LCD_WR_REG(0xED);  
	LCD_WR_DATA(0x64); 
	LCD_WR_DATA(0x03); 
	LCD_WR_DATA(0X12); 
	LCD_WR_DATA(0X81); 

	LCD_WR_REG(0xE8);  
	LCD_WR_DATA(0x85); 
	LCD_WR_DATA(0x10); 
	LCD_WR_DATA(0x78); 

	LCD_WR_REG(0xCB);  
	LCD_WR_DATA(0x39); 
	LCD_WR_DATA(0x2C); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x34); 
	LCD_WR_DATA(0x02); 

	LCD_WR_REG(0xF7);  
	LCD_WR_DATA(0x20); 

	LCD_WR_REG(0xEA);  
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00); 

	LCD_WR_REG(0xC0);    //Power control 
	LCD_WR_DATA(0x21);   //VRH[5:0] 

	LCD_WR_REG(0xC1);    //Power control 
	LCD_WR_DATA(0x12);   //SAP[2:0];BT[3:0] 

	LCD_WR_REG(0xC5);    //VCM control 
	LCD_WR_DATA(0x32); 	 //3F
	LCD_WR_DATA(0x3C); 	 //3C

	LCD_WR_REG(0xC7);    //VCM control2 
	LCD_WR_DATA(0XC1); 

	LCD_WR_REG(0x36);    // Memory Access Control 
	LCD_WR_DATA(0x08); 

	LCD_WR_REG(0x3A);   
	LCD_WR_DATA(0x55); 

	LCD_WR_REG(0xB1);   
	LCD_WR_DATA(0x00);   
	LCD_WR_DATA(0x18); 

	LCD_WR_REG(0xB6);    // Display Function Control 
	LCD_WR_DATA(0x0A); 
	LCD_WR_DATA(0xA2); 

	LCD_WR_REG(0xF2);    // 3Gamma Function Disable 
	LCD_WR_DATA(0x00); 

	LCD_WR_REG(0x26);    //Gamma curve selected 
	LCD_WR_DATA(0x01); 

	LCD_WR_REG(0xE0);    //Set Gamma 
	LCD_WR_DATA(0x0F); 
	LCD_WR_DATA(0x20); 
	LCD_WR_DATA(0x1E); 
	LCD_WR_DATA(0x09); 
	LCD_WR_DATA(0x12); 
	LCD_WR_DATA(0x0B); 
	LCD_WR_DATA(0x50); 
	LCD_WR_DATA(0XBA); 
	LCD_WR_DATA(0x44); 
	LCD_WR_DATA(0x09); 
	LCD_WR_DATA(0x14); 
	LCD_WR_DATA(0x05); 
	LCD_WR_DATA(0x23); 
	LCD_WR_DATA(0x21); 
	LCD_WR_DATA(0x00); 	

	LCD_WR_REG(0XE1);    //Set Gamma 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x19); 
	LCD_WR_DATA(0x19); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x12); 
	LCD_WR_DATA(0x07); 
	LCD_WR_DATA(0x2D); 
	LCD_WR_DATA(0x28); 
	LCD_WR_DATA(0x3F); 
	LCD_WR_DATA(0x02); 
	LCD_WR_DATA(0x0A); 
	LCD_WR_DATA(0x08); 
	LCD_WR_DATA(0x25); 
	LCD_WR_DATA(0x2D); 
	LCD_WR_DATA(0x0F); 

	LCD_WR_REG(0x11); //Exit Sleep
	HAL_Delay(500);
	LCD_WR_REG(0x29); //display on	

	LCD_WR_REG(0X36);
	LCD_WR_DATA(0x68);   //横屏,需从下到上,从左到右扫描,BGR panel

	LCD_Set_Window(0,0,LCDW,LCDH);	//设置扫描窗口 320*240 
	LCD_Clear(WHITE);           //白色	
}  
/*********************************************************************************************************
** 函数名称:LCD_SetOnePixel
** 函数功能:画某个点位置上的颜色
** 输入参数:	
** 输出参数:	无
** 返回值:		无
** 备注：
*********************************************************************************************************/
void LCD_SetOnePixel(uint16_t X, uint16_t Y,uint16_t color)
{	 	    
	LCD_WR_REG(0x2A); 
	LCD_WR_DATA(X>>8); 
	LCD_WR_DATA(X&0xFF);	 
	LCD_WR_REG(0x2B); 
	LCD_WR_DATA(Y>>8); 
	LCD_WR_DATA(Y&0xFF);
	
	LCD->LCD_REG=0x2C;
	LCD->LCD_RAM=color>>8;
	LCD->LCD_RAM=color&0xFF;
} 		 
/*********************************************************************************************************
** 函数名称:LCD_Set_Window
** 函数功能:	设置窗口,并自动设置画点坐标到窗口左上角(sx,sy).
** 输入参数:	
** 输出参数:	无
** 返回值:		无
** 备注：窗口宽度和高度,必须大于0!!,使用完后,需再设置一次恢复,默认窗口 320*240 
*********************************************************************************************************/
void LCD_Set_Window(uint16_t sx,uint16_t sy,uint16_t width,uint16_t height)
{   
	width=sx+width-1;
	height=sy+height-1;
	LCD_WR_REG(0x2A); 
	LCD_WR_DATA(sx>>8); 
	LCD_WR_DATA(sx&0xFF);	 
	LCD_WR_DATA(width>>8); 
	LCD_WR_DATA(width&0xFF);  
	LCD_WR_REG(0x2B); 
	LCD_WR_DATA(sy>>8); 
	LCD_WR_DATA(sy&0xFF); 
	LCD_WR_DATA(height>>8); 
	LCD_WR_DATA(height&0xFF); 
} 
/*********************************************************************************************************
** 函数名称:LCD_Clear
** 函数功能:	清屏函数
** 输入参数:	颜色代码
** 输出参数:	无
** 返回值:		无
** 备注：
*********************************************************************************************************/
void LCD_Clear(uint16_t color)
{
	uint32_t index=0;      
	uint32_t totalpoint=LCDW*LCDH;  	//得到总点数
	
	//设置光标位置 
	LCD_WR_REG(0x2A); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00);	 
	LCD_WR_REG(0x2B); 
	LCD_WR_DATA(0x00); 
	LCD_WR_DATA(0x00);
	LCD_WriteRAM_Prepare();     		//开始写入GRAM	 
	for(index=0;index < totalpoint;index++)
	{
		LCD->LCD_RAM=color>>8;	
		LCD->LCD_RAM=color&0xFF;
	}
}

//在指定区域内填充指定数据，起始坐标(sx,sy),区域大小为:width*height 
void LCD_Set_WindowData(uint16_t sx,uint16_t sy,uint16_t width,uint16_t height,uint16_t data)
{  
	uint32_t index; 
	uint32_t totalpoint=width*height;  	//得到总点数
	
	LCD_Set_Window(sx,sy,width,height);    //设置填充数据的窗口
	LCD_WriteRAM_Prepare(); 		//开始写入GRAM	
 	for(index=0;index < totalpoint;index++)
 	{
		LCD->LCD_RAM=data>>8;
		LCD->LCD_RAM=data&0xFF;
	}
	LCD_Set_Window(0,0,LCDW,LCDH);  //回复默认窗口 320*240 
}
//在指定位置显示一个字符
//x,y:起始坐标
//num:要显示的字符:" "--->"~"
//size:字体大小 12/16/24
//mode:叠加方式(1)还是非叠加方式(0)
void LCD_ShowChar(uint16_t x, uint16_t y, uint8_t num, uint8_t size, uint8_t mode)
{
    uint8_t temp, t1, t;
    uint16_t y0 = y;
    uint8_t csize = (size / 8 + ((size % 8) ? 1 : 0)) * (size / 2); //得到字体一个字符对应点阵集所占的字节数
    num = num - ' '; //得到偏移后的值（ASCII字库是从空格开始取模，所以-' '就是对应字符的字库）
    for (t = 0; t < csize; t++)
    {
        if (size == 12)temp = asc2_1206[num][t];    //调用1206字体
        else if (size == 16)temp = asc2_1608[num][t]; //调用1608字体
        else if (size == 24)temp = asc2_2412[num][t]; //调用2412字体
        else return;                                //没有的字库
        for (t1 = 0; t1 < 8; t1++)
        {
            if (temp & 0x80)LCD_SetOnePixel(x, y, RED);
            else if (mode == 0)LCD_SetOnePixel(x, y, BLACK);
            temp <<= 1;
            y++;
            if (y >= LCDH)return;  //超区域了
            if ((y - y0) == size)
            {
                y = y0;
                x++;
                if (x >= LCDW)return; //超区域了
                break;
            }
        }
    }
}

//显示字符串
//x,y:起点坐标
//width,height:区域大小
//size:字体大小
//*p:字符串起始地址
void LCD_ShowString(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t size, uint8_t *p)
{
    uint16_t x0 = x;
    width += x;
    height += y;
    while ((*p <= '~') && (*p >= ' ')) //判断是不是非法字符!
    {
        if (x >= width)
        {
            x = x0;
            y += size;
        }
        if (y >= height)break; //退出
        LCD_ShowChar(x, y, *p, size, 0);
        x += size / 2;
        p++;
    }
}

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
