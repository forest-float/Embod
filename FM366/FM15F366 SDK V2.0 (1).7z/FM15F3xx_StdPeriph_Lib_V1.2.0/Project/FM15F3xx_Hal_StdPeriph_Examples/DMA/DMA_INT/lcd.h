#ifndef __LCD_H
#define __LCD_H		
#include "fm15f3xx_hal.h"
#include "fm15f3xx_conf.h"
//LCD地址结构体, A17作为数据命令区分线   
typedef struct
{
	__IO uint8_t LCD_REG;
	__IO uint8_t LCD_RAM;
} LCD_TypeDef;
//#define LCD_BASE	((uint32_t)(0x18000000 | 0x0001FFFF))  //8位数据宽度
#define LCD_BASE	((uint32_t)(0x18000000 | 0x0003FFFF))  //16位数据宽度
#define LCD         ((LCD_TypeDef *) LCD_BASE)	  

#define LCDW	320
#define LCDH	240
//////////////////////////////////////////////////////////////////////////////////
//画笔颜色
#define WHITE            0xFFFF
#define BLACK            0x0000	  
#define BLUE             0x001F  
#define BRED             0XF81F
#define GRED 	           0XFFE0
#define GBLUE	           0X07FF
#define RED              0xF800
#define MAGENTA          0xF81F
#define GREEN            0x07E0
#define CYAN             0x7FFF
#define YELLOW           0xFFE0
#define BROWN 		       0xBC40 //棕色
#define BRRED 		       0xFC07 //棕红色
#define GRAY  		       0x8430 //灰色
#define DARKBLUE      	 0X01CF	//深蓝色
#define LIGHTBLUE      	 0X7D7C	//浅蓝色  
#define GRAYBLUE       	 0X5458 //灰蓝色
#define LIGHTGREEN     	 0X841F //浅绿色
#define LGRAY 			     0XC618 //浅灰色(PANNEL),窗体背景色
#define LGRAYBLUE        0XA651 //浅灰蓝色(中间层颜色)
#define LBBLUE           0X2B12 //浅棕蓝色(选择条目的反色)
	    															  
void LCD_Init(void);
void LCD_Clear(uint16_t Color);
void LCD_SetOnePixel(uint16_t X, uint16_t Y,uint16_t color);
void LCD_Set_Window(uint16_t sx,uint16_t sy,uint16_t width,uint16_t height);

void LCD_Set_WindowData(uint16_t sx,uint16_t sy,uint16_t width,uint16_t height,uint16_t data);
void LCD_ShowString(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t size, uint8_t *p);
void LCD_ShowChar(uint16_t x, uint16_t y, uint8_t num, uint8_t size, uint8_t mode);

#endif
