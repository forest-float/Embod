/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"


int main(void)
{
	uint32_t len=0;
	uint8_t Data[256] = {0x00};
	
	HAL_Init();
	
	printf("I2C Slave\r\n"); 
	
  delay_ms(1000);
	
  len =256;
	
	while(1)
	{		
    I2Cx_SlaveRxTxBytes(&I2C_Handle, Data, &len);
	
//	for(int i =0; i<len; i++)
//		printf("%d",Data[i]);
//	printf("\n");

		LED_Toggle();//��˸LED,��ʾϵͳ��������.
	}
	
}
