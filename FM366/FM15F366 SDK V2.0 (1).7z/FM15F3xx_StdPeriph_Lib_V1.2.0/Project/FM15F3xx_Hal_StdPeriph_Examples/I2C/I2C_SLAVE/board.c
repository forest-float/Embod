/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.DigitFiltEn   = GPIO_DIGITFILTE_OFF;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_LOW;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

I2C_HandleTypeDef I2C_Handle;

void I2C_Init(uint32_t bound)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	I2C_Handle.Instance          = I2C1;
	I2C_Handle.Init.Mode	       = I2C_MODE_SLAVE;	  
	I2C_Handle.Init.ClockSpeed   = bound;	
	I2C_Handle.Init.OwnAddress   = 0x50;
	I2C_Handle.Init.OwnAddrSize  = I2C_ADDRESS_7BIT;
	I2C_Handle.Init.StretchEn    = I2C_SLAVE_STRETCH_DISABLE;
	HAL_I2C_Init(&I2C_Handle);
	
	//I2C_SCL --->PC8
	//I2C_SDA --->PC9
	GPIO_InitStruct.PuPd = GPIO_PULLUP;
	GPIO_InitStruct.Alt  = GPIO_AF4_I2C1;
	GPIO_InitStruct.Pin  = GPIO_PIN_8 | GPIO_PIN_9; 
	HAL_GPIO_Init(GPIOC,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	delay_init(180);
	UART_Init(115200);
	LED_Init();
	I2C_Init(400000);
}

void LED_Toggle(void)
{
	HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}
