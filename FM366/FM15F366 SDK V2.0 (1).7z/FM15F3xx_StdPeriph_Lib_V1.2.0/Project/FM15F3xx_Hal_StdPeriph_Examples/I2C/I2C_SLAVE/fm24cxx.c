/**
  ******************************************************************************
  * @file    I2C.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "fm15f3xx_conf.h"
#include "fm24cxx.h"
#include "uart.h"
#include "delay.h"

#define I2C_TIMEOUT	25  //25ms
#define I2CX_IRQn		I2C1_IRQn
#define SLAVE_7ADDR 0x50



/**
  * @brief  I2C bus check ststus
  * @param  I2C_TypeDef *I2Cx
  * @retval SUCCESS,ERROR
  */
uint32_t I2C_BusStatus(I2C_HandleTypeDef *hi2c)
{
	uint32_t retval;
  //配置管脚	
  if(hi2c->Instance == I2C0)
  {
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_6, LL_GPIO_ALT_1); //GPIO
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_7, LL_GPIO_ALT_1); //GPIO
		retval = (GPIOC->PDIR)&0x00C0;
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_6, LL_GPIO_ALT_4); //I2C1_SCL
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_7, LL_GPIO_ALT_4); //I2C1_SDA
		if(0x00C0 != retval)
		{
			printf("I2C bus IO error -> %04X \r\n",retval>>6);
			return HAL_BUSY;
		}			
		return HAL_OK;			
  }
  else if (hi2c->Instance == I2C1)
  {
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_8, LL_GPIO_ALT_1); //GPIO  
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_9, LL_GPIO_ALT_1); //GPIO
	  retval = (GPIOC->PDIR)&0x0300;
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_8, LL_GPIO_ALT_4); //I2C1_SCL  
    LL_GPIO_SetPinMux(GPIOC, LL_GPIO_PIN_9, LL_GPIO_ALT_4); //I2C1_SDA			
		if(0x0300 != retval)
		{
			printf("I2C bus IO error -> %04X \r\n",retval>>8);
			return HAL_BUSY;
		}			
		return HAL_OK;
  }
return HAL_BUSY;		
}



uint32_t SendStart(I2C_HandleTypeDef *hi2c)
{
	return HAL_I2C_START(hi2c, I2C_TIMEOUT);
}

uint32_t SendStop(I2C_HandleTypeDef *hi2c)//多发一个STOP，保证slave不挂住总线。
{
	if(HAL_OK !=HAL_I2C_STOP(hi2c, I2C_TIMEOUT))
	{
		printf("I2CM SendStop Fail-> %08X \r\n",hi2c->Instance->MSSPSTAT);
		delay_ms(10);
	}	
	delay_us(10);
	if(HAL_OK != I2C_BusStatus(hi2c))//i2c bus IO error
	{
		delay_ms(10);
		return HAL_I2C_STOP(hi2c, I2C_TIMEOUT);	
	}
  return SUCCESS;
}

/**
  * @brief  I2C _Master Send&Recieve Bytes
  * @param  I2C_TypeDef *I2Cx,const uint8_t deviceaddr, uint8_t* pInfo, uint16_t *nCount
  * @retval none
     1.主机发出开始信号
     2.主机接着发出一字节的从机地址，其中最低位为读写控制码（1为读、0为写） 高七位为从机器件地址
     3.从机发出ACK信号
     4.主机开始发送数据，每发完一字节后，从机发出ACK信号给主机
     5.主机发完或收到NACK，发出停止信号
  */
uint32_t I2Cx_MasterTxRxBytes(I2C_HandleTypeDef *hi2c, uint8_t deviceaddr, uint8_t* pData, uint32_t* len)
{
  uint32_t retrytimes=3;
  uint32_t retval,i;

	while(retrytimes--)
	{	  
    __HAL_I2C_DISABLE(hi2c);
		__HAL_I2C_MASTER_ENABLE(hi2c);
		delay_us(10);
		//等待bus空闲
		if(HAL_OK != I2C_BusStatus(hi2c))//i2c bus IO error
		{		
			SendStop(hi2c);
			delay_ms(10);
			continue;
		}
	  //1,send start
		retval = SendStart(hi2c);
		if(HAL_BUSY == retval)
		{
			continue;
		}
		else if(HAL_OK == retval)
		{
			//2, send addr
			delay_us(10);
			retval =HAL_I2C_Master_SendByte(hi2c,deviceaddr,I2C_TIMEOUT);
			if(HAL_OK == retval) break; 
			SendStop(hi2c);	
			printf("I2CM addr Error-> %02X \r\n",retval);
			delay_ms(10);
			return HAL_ERROR;
		}
		
		if(0 == retrytimes)
		{
			if(HAL_OK !=SendStop(hi2c)) 
			{
				__HAL_I2C_DISABLE(hi2c);	
			}
			return HAL_ERROR;
		}
	}
	
	delay_us(100);
	//3,read data
	if(0x01&deviceaddr)
	{
		 /* 主机开始接收数据，每收完一字节后，主机发出ACK信号给从机，接收最后一个数据，主机回NACK	*/
	  for(i=0; i<*len-1;i++)
		{		
			retval =HAL_I2C_Master_RecvByte(hi2c,&pData[i],1,I2C_TIMEOUT);
			if(HAL_OK != retval) 
			{
				SendStop(hi2c);
				return HAL_ERROR;
			}		
		}
		
		//4,last byte send NACK	
		if(HAL_OK == HAL_I2C_Master_RecvByte(hi2c,&pData[i],0,I2C_TIMEOUT)) 
		{
			*len = i+1;
			return HAL_OK;
		}
		else
		{
			return HAL_ERROR;
		}	
	}
	else
	{//3,send data
		for(i=0; i<*len; i++)
		{			
			retval = HAL_I2C_Master_SendByte(hi2c,pData[i],I2C_TIMEOUT);
			if(HAL_OK == retval) 
        continue;
			else 
        return HAL_ERROR;
		}
	}
	//5,send stop
	delay_us(100);
	SendStop(hi2c);
	return HAL_OK;		
}


/**
  * @brief  I2C_Slave Recieve or Send Bytes
  * @param  I2C_TypeDef *I2Cx,uint8_t* pInfo, uint16_t *nCount
  * @retval none
     1.主机发出开始信号
     2.主机接着发出一字节的从机地址，其中最低位为读写控制码（1为读、0为写） 高七位为从机器件地址
     3.从机发出地址ACK信号
     4.若从机收到RW=1,主机开始接收数据，每收完一字节后，主机发出ACK信号给从机，
       若从机收到RW=0,主机开始发送数据，从机每收完一字节后，发出ACK信号给主机， 
		 5.主机接收最后一个数据，主机回NACK
     6.主机发出停止信号
  */
uint32_t I2Cx_SlaveRxTxBytes(I2C_HandleTypeDef *hi2c, uint8_t* pData, uint32_t *len)
{
	uint32_t rw=0, count,regval;
	uint8_t  SW[2] = {0x90,0x00};
	

//	/* Check Bus is idle*/
//  for(count =0;count < 3;count++)
//	{
//		/* Wait Bus idle */
//		if(HAL_OK == I2C_BusStatus(hi2c)) break;
//		/*i2c bus IO error */		
//		HAL_I2C_Slave_Reset(hi2c);
//		/*只有这种方式才能关闭slave模式,释放总线HOLD */
//		hi2c->Instance->MEN |= I2C_MODE;
//		delay_us(200);
//		printf("IO:%d\n",count);
//		if(2 == count)
//		{
//			*len =0;
//			return HAL_ERROR;			
//		}
//  }
	__HAL_I2C_SLAVE_ENABLE(hi2c);
	HAL_I2C_Slave_Reset(hi2c);	
	
	//1,waiting start	and addr
	if(HAL_OK != HAL_I2C_Slave_WaitOnStartAndAddress(hi2c,&rw,2000))   
	{
	  HAL_I2C_Slave_Reset(hi2c);
		/*只有这种方式才能关闭slave模式,释放总线HOLD */
		hi2c->Instance->MEN |= I2C_MODE;
		*len =0;
		return HAL_ERROR;
	}
	
	//2,send data
	if(I2C_SLAVE_FLAG_WRITE & rw)
	{
		if(0 == *len)
		{
			//发送buff无数据，回发sw = 9000
			if(HAL_OK == HAL_I2C_Slave_SendByte(hi2c,SW[0],I2C_TIMEOUT)) 
			{
				HAL_I2C_Slave_SendByte(hi2c,SW[1],I2C_TIMEOUT);
			}
	  }
		else
		{						
			for(count = 0; count<*len; count++)	
			{
				if(HAL_OK == HAL_I2C_Slave_SendByte(hi2c,pData[count],I2C_TIMEOUT)) continue;//无错，继续	
			}
		}
		/* Wait STOP */		
		while(HAL_OK == HAL_I2C_Slave_SendByte(hi2c,0xFF,I2C_TIMEOUT));
		/*i2c bus IO error */		
		HAL_I2C_Slave_Reset(hi2c);
		/*只有这种方式才能关闭slave模式,释放总线HOLD */
		hi2c->Instance->MEN |= I2C_MODE;
		if(count == (*len) )
		{	
			return HAL_OK;
		}
		else
		{
			return HAL_ERROR;
		}		
	}	
	
	//2,Recieve data,send ACK
	count=0;
	while(1)
	{
    if(HAL_BUSY == HAL_I2C_Slave_RecvByte(hi2c,&pData[count],1,I2C_TIMEOUT)) 
		{			
			count++;
			continue;
		}
			
		*len = count; //实际接受到数据长度		
	
    /*i2c bus IO error */		
		HAL_I2C_Slave_Reset(hi2c);
		/*只有这种方式才能关闭slave模式,释放总线HOLD */
		hi2c->Instance->MEN |= I2C_MODE;

		if(0 == count)	
			return HAL_ERROR;
		
		return HAL_OK;		
	}

}

/**
  * @brief  I2C0_Handler
  * @param  none
  * @retval none
  */
void I2C0_Handler(void)
{
	printf("I2C0_Handler ! \n");
}

/**
  * @brief  I2C1_Handler
  * @param  none
  * @retval none
  */
void I2C1_Handler(void)
{
	printf("I2C1_Handler ! \n");
}







