/**
  ******************************************************************************
  * @file    I2C.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __I2C_H_
#define __I2C_H_


#ifdef __cplusplus
 extern "C" {
#endif


#include "fm15f3xx.h"
#include "fm15f3xx_conf.h"

typedef enum
{
  I2C_START = 0,
  I2C_ADDRESS ,
	I2C_DATA,
	I2C_STOP
} I2C_Slave_Status;	 

uint32_t I2Cx_MasterTxRxBytes(I2C_HandleTypeDef *hi2c, uint8_t deviceaddr, uint8_t* pData, uint32_t* len);
uint32_t I2Cx_SlaveRxTxBytes(I2C_HandleTypeDef *hi2c, uint8_t* pData, uint32_t *len);

#ifdef __cplusplus
}
#endif
#endif
