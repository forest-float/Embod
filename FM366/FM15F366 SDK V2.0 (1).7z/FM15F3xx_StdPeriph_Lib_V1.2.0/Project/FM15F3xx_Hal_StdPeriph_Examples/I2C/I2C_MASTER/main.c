/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"


int main(void)
{
	uint32_t retval;
	uint8_t Data[256] = {0x00};
	uint8_t Data1[256] = {0x00};	
	uint32_t len=0;
	HAL_Init();
	
	printf("I2C\r\n"); 
	
  delay_ms(1000);
	
	for(int i =0; i<256; i++)
    Data[i] =i;

  len =256;
	
	while(1)
	{
	retval = I2Cx_MasterTxRxBytes(&I2C_Handle,0xA0,Data,&len);
  if(HAL_OK == retval)
  	printf("I2CM Send success! \r\n");
  else
  {
  	printf("I2CM Senddata fail! \r\n");
		delay_ms(1000);
		continue;
  }		
  delay_us(10000); //������С���>us
	
  len =256;
  retval = I2Cx_MasterTxRxBytes(&I2C_Handle,0xA1,Data1,&len);//read
  
	printf("Len:%d\n",len);
  if(HAL_OK == retval)
  {
		printf("Data:\n");
		for(int i =0; i<len;i++)
		  printf("%d",Data1[i]);
		printf("\r\n");
  }
  else			
  	printf("I2CM Recvdata fail-> %02d \r\n",retval);


		LED_Toggle();//��˸LED,��ʾϵͳ��������.
	  delay_ms(1000);
	}
	
}
