#include "fm15f3xx.h"
#include "fm15f3xx_conf.h"

#ifndef __SPI_FLASH_H
#define __SPI_FLASH_H

#define SPI3_SSN_PIN	LL_BKP_PIN1
#define SPI3_MOSI_PIN	GPIO_PIN_2
#define SPI3_MISO_PIN	GPIO_PIN_1
#define SPI3_SCK_PIN	GPIO_PIN_0
#define SPI_PORT		GPIOE
 
void FLASH_ReadID(uint8_t * pData);
uint8_t FLASH_ReadSR(uint8_t Reg);
void FLASH_WriteStatus(uint8_t* status);
void FLASH_EraseChip(uint8_t IsQPI);
void FLASH_EraseSector(uint32_t Dst_Addr);
void FLASH_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead);
void FLASH_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint32_t NumByteToWrite);

#endif /* __SPI_FLASH_H */

