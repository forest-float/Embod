 /**
  ******************************************************************************
  * @file    bsp_xxx.c
  * @author  
  * @version V1.0
  * @date    
  * @brief   spi flash 底层应用函数bsp 
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
  
#include "fm25qxx.h"
#include "board.h"


#define FLASH_TIMEOUT  100     //100ms
//#define SPI_FLASH_PageSize            4096
#define SPI_FLASH_PageSize              256
#define SPI_FLASH_PerWritePageSize      256
/* Private typedef -----------------------------------------------------------*/
#define FM25Q32     
//#define FM25Q32 
/* W25Q32 Private define ------------------------------------------------------------*/
#ifdef W25Q32
#define W25X_WriteEnable		      0x06 
#define W25X_WriteDisable		      0x04 
#define W25X_ReadStatusReg		    0x05 
#define W25X_WriteStatusReg		    0x01 
#define W25X_ReadData			        0x03 
#define W25X_FastReadData		      0x0B 
#define W25X_FastReadDual		      0x3B 
#define W25X_PageProgram		      0x02 
#define W25X_BlockErase			      0xD8 
#define W25X_SectorErase		      0x20 
#define W25X_ChipErase			      0xC7 
#define W25X_PowerDown			      0xB9 
#define W25X_ReleasePowerDown	    0xAB 
#define W25X_DeviceID			        0x9F 
#define W25X_ManufactDeviceID   	0x90 
#define W25X_JedecDeviceID		    0x9F 
#define WIP_Flag                  0x01  /* Write In Progress (WIP) flag */
#define Dummy_Byte                0xFF
#endif

/*FM25Q32 Standard SPI Private define------------------------------------------------------------*/
#ifdef FM25Q32
#define FM25X_WriteEnable		        0x06
#define FM25X_WriteDisable		      0x04 
#define FM25X_ReadStatusReg1		    0x05
#define FM25X_ReadStatusReg2		    0x35
#define FM25X_WriteStatusReg		    0x01 
#define FM25X_ReadData			        0x03 
#define FM25X_FastReadData		      0x0B 
#define FM25X_SectorErase_4k		    0x20 
#define FM25X_BlockErase_32k		    0x52
#define FM25X_BlockErase_64k		    0xD8 
#define FM25X_ChipErase			        0xC7 
#define FM25X_FastReadDual		      0x3B 
#define FM25X_PageProgram		        0x02 
#define FM25X_ChipErase			        0xC7 
#define FM25X_PowerDown			        0xB9 
#define FM25X_ReleasePowerDown	    0xAB 
#define FM25X_DeviceID			        0x92 
#define FM25X_ManufactDeviceID     	0x90 
#define FM25X_JedecDeviceID		      0x9F
#define FM25X_QPIEnable		          0x38 
#define WIP_Flag                    0x01  /* Write In Progress (WIP) flag */
#define FM25X_ResetEnable		        0x66
#define FM25X_Reset	                0x99
#define FM25X_SecuritySectorErase       0x44
#define FM25X_SecuritySectorProgram     0x42
#define FM25X_SecuritySectorRead        0x48
#define Dummy_Byte                      0xFF
#endif


#define FLASH_CS(value) ((value)?(LL_BKP_GPIO_SetOutputPin(SPI3_SSN_PIN)):(LL_BKP_GPIO_ResetOutputPin(SPI3_SSN_PIN)))  //选中FLASH


	
/*******************************************************************************
* Function Name  : SPI_FLASH_SectorErase
* Description    : Erases the specified FLASH sector.
* Input          : SectorAddr: address of the sector to erase.
* Output         : None
* Return         : None
*******************************************************************************/
void FLASH_ReadID(uint8_t * pData)
{
  uint8_t cmd=0,DummyByte[3]={0xFF,0xFF,0xFF}; 
 
  /* Select the FLASH: Chip Select low */
  FLASH_CS(0);
  /* Send "RDID " instruction */
	cmd = FM25X_JedecDeviceID; 
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
  /* Read a byte from the FLASH */
	HAL_SPI_TransmitReceive(&SPI_Handler, DummyByte, pData, 3, FLASH_TIMEOUT);
  /* Deselect the FLASH: Chip Select high */
  FLASH_CS(1);
}

/*******************************************************************************
* Function Name  : SPI_FLASH_WriteEnable
* Description    : Enables the write access to the FLASH.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void FLASH_WriteEnable(void)
{
	uint8_t cmd;
  /* Select the FLASH: Chip Select low */
  FLASH_CS(0);
  /* Send "Write Enable" instruction */
	cmd =FM25X_WriteEnable;
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
  /* Deselect the FLASH: Chip Select high */
  FLASH_CS(1);
}


//读取SPI_FLASH Register-1状态寄存器,默认:0x00.BIT0,BUSY:忙标记位(1,忙;0,空闲);
uint8_t FLASH_ReadSR(uint8_t Reg)   
{  
	uint8_t cmd,DummyByte[1]={0xFF},statue=0;
	
	switch(Reg)
  {
		case 1:
				cmd = FM25X_ReadStatusReg1; 
				break;
		case 2:
				cmd = FM25X_ReadStatusReg2; 
				break;
  }
  FLASH_CS(0);	//使能器件  
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	/* Read a byte from the FLASH */
	HAL_SPI_TransmitReceive(&SPI_Handler, DummyByte, &statue, 1, FLASH_TIMEOUT);
	FLASH_CS(1);  //取消片选    
	return statue;
}


//写状态,包括状态寄存器1和2
void FLASH_WriteStatus(uint8_t* status)
{
	FLASH_WriteEnable();					//SET WEL 	

  FLASH_CS(0);	//使能器件 
	HAL_SPI_Transmit(&SPI_Handler, status, 2, FLASH_TIMEOUT);
	FLASH_CS(1);  //取消片选 	
}

//擦除整个芯片		  
//等待时间超长32s
void FLASH_EraseChip(uint8_t IsQPI)   
{
	uint8_t cmd;
	FLASH_WriteEnable();					//SET WEL 	
	
  FLASH_CS(0);	//使能器件 
	cmd = FM25X_ChipErase;
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	FLASH_CS(1);  //取消片选 
	
	while(FLASH_ReadSR(1) & 0x01); //等待FLASH执行结束
} 

//擦除一个扇区
//Dst_Addr:扇区地址 根据实际容量设置
//擦除一个扇区的最少时间:90ms
void FLASH_EraseSector(uint32_t Dst_Addr) 
{
	uint8_t cmd;
  FLASH_WriteEnable();					//SET WEL	
	
 	Dst_Addr*=4096;
  FLASH_CS(0);	//使能器件 
	cmd = FM25X_SectorErase_4k;
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	for(int i=2; i>=0;i--)
	{
		cmd = (uint8_t)(Dst_Addr >> (i*8));
		HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	}
	FLASH_CS(1);  //取消片选 

	while(FLASH_ReadSR(1) & 0x01) ; //等待FLASH执行结束
}

//在指定地址开始读取指定长度的数据
//pBuffer:数据存储区
//ReadAddr:开始读取的地址(最大32bit)
//NumByteToRead:要读取的字节数
void FLASH_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead)   
{
	uint8_t cmd;	
	FLASH_CS(0);	//使能器件 
//	cmd = FM25X_FastReadData;
	cmd = 0x03;
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	for(int i=2; i>=0;i--)
	{
		cmd = (uint8_t)(ReadAddr >> (i*8));
		HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	}
	/* Dummy */
	cmd = 0xFF;
//	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);	
	/* Read a byte from the FLASH */
	for(int i=0; i < NumByteToRead; i++)
	{
	  HAL_SPI_TransmitReceive(&SPI_Handler, &cmd, pBuffer++, 1, FLASH_TIMEOUT);
	}
	FLASH_CS(1);  //取消片选
}


//SPI在一页(0~65535)内写入少于255个字节的数据
//在指定地址开始写入最大255字节的数据
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)
//NumByteToWrite:要写入的字节数(最大256),该数不应该超过该页的剩余字节数!!!	 
void FLASH_WritePage(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite)
{
 	uint8_t cmd;	
	FLASH_WriteEnable();					//SET WEL	

	FLASH_CS(0);	//使能器件 
	cmd = FM25X_PageProgram;
	HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	for(int i=2; i>=0;i--)
	{
		cmd = (uint8_t)(WriteAddr >> (i*8));
		HAL_SPI_Transmit(&SPI_Handler, &cmd, 1, FLASH_TIMEOUT);
	}
	/* Write a byte to the FLASH */
	for(int i=0; i < NumByteToWrite; i++)
	{
		HAL_SPI_Transmit(&SPI_Handler, pBuffer++, 1, FLASH_TIMEOUT);
	}
	FLASH_CS(1);  //取消片选  
  
  while(FLASH_ReadSR(1) & 0x01);
} 

//无检验写SPI FLASH 
//必须确保所写的地址范围内的数据全部为0XFF,否则在非0XFF处写入的数据将失败!
//具有自动换页功能 
//在指定地址开始写入指定长度的数据,但是要确保地址不越界!
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)
//NumByteToWrite:要写入的字节数(最大4096)
//CHECK OK
static void FLASH_WriteNoCheck(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite)   
{ 			 		 
	uint16_t pageremain;	   
	pageremain = 256-WriteAddr%256; //页剩余的字节数		 	   
	if(NumByteToWrite <= pageremain) pageremain = NumByteToWrite; //不大于256个字节
	while(1)
	{
		FLASH_WritePage(pBuffer,WriteAddr,pageremain);
		if(NumByteToWrite == pageremain) break;//写入结束了
	 	else //NumByteToWrite>pageremain
		{
			pBuffer += pageremain;
			WriteAddr += pageremain;
			NumByteToWrite -= pageremain;			  //减去已经写入了的字节数
			if(NumByteToWrite > 256)
				pageremain = 256; //一次可以写入256个字节
			else 
				pageremain = NumByteToWrite; 	  //不够256个字节了
		}
	}   
} 

//写 FLASH  
//在指定地址开始写入指定长度的数据
//该函数带擦除操作!
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)						
//NumByteToWrite:要写入的字节数   
static uint8_t SECTOR_BUFFER[4096];		 
void FLASH_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint32_t NumByteToWrite)   
{ 
	uint32_t secpos;
	uint16_t secoff, secremain, i;    
	uint8_t * SECTOR;	  
  SECTOR = SECTOR_BUFFER;	     
 	secpos=WriteAddr/4096;//扇区地址  
	secoff=WriteAddr%4096;//在扇区内的偏移
	secremain=4096-secoff;//扇区剩余空间大小   
 	if(NumByteToWrite <= secremain)secremain = NumByteToWrite;//不大于4096个字节
	while(1) 
	{	
		FLASH_Read(SECTOR,secpos*4096,4096);//读出整个扇区的内容
		for(i=0; i<secremain; i++)//校验数据
		{
			if(SECTOR[secoff+i]!=0XFF)break;//需要擦除  	  
		}
		
		if(i<secremain)//需要擦除
		{
			FLASH_EraseSector(secpos);//擦除这个扇区
			for(i=0; i<secremain; i++)	   //复制
			{
				SECTOR[i+secoff] = pBuffer[i];	  
			}
			
			FLASH_WriteNoCheck(SECTOR,secpos*4096,4096);	//写入整个扇区   
		}
		else 
		{
		  FLASH_WriteNoCheck(pBuffer,WriteAddr,secremain);//写已经擦除了的,直接写入扇区剩余区间.
		}			
		if(NumByteToWrite == secremain)
		{
			break;//写入结束了
		}
		else//写入未结束
		{
			secpos++;//扇区地址增1
			secoff = 0;//偏移位置为0 	 

		  pBuffer += secremain;  //指针偏移
			WriteAddr += secremain;//写地址偏移	   
		  NumByteToWrite -= secremain;				//字节数递减
			if(NumByteToWrite>4096)secremain = 4096;	//下一个扇区还是写不完
			else secremain = NumByteToWrite;			//下一个扇区可以写完了
		}	 
	}	 
}

/*********************************************END OF FILE**********************/
