/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"


int main(void)
{
  uint8_t txbuff[10]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A};
	uint8_t txbuff1[10]={0};
	uint8_t id[3];
  HAL_Init();
	printf("\nFlashID:");	
	FLASH_ReadID(id);
	for(int i=0; i<3; i++)
	  printf("%X",id[i]);

	printf("\nд������:\n");		
	FLASH_Write(txbuff,0x001000,10);
	printf("������:\n");	
	FLASH_Read(txbuff1,0x001000,10);	
  for(int i=0; i<10; i++)
	{
   printf("%X",txbuff1[i]); 
		if(txbuff1[i] !=txbuff[i])
				printf("\n���ݶ�ȡ����:\n");
	}		
	
	while(1)
	{
    HAL_Delay(1000);
	}
}
