/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif


SPI_HandleTypeDef SPI_Handler;
void SPI_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
	
	//SSN
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(SPI3_SSN_PIN);
	LL_BKP_GPIO_SetOutputPin(SPI3_SSN_PIN); //����
  //MOSI\MISO\SCK
  GPIO_InitStruct.Pin  = SPI3_MOSI_PIN|SPI3_MISO_PIN|SPI3_SCK_PIN;
  GPIO_InitStruct.Alt  = GPIO_AF2_SPI3;
  GPIO_InitStruct.PuPd = GPIO_NOPULL;
  HAL_GPIO_Init(SPI_PORT,&GPIO_InitStruct);
  
  SPI_Handler.Instance               = SPI3;
  SPI_Handler.Init.Mode              = SPI_MODE_MASTER;	
  SPI_Handler.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_4;
  SPI_Handler.Init.ClkPhase          = SPI_PHASE_1EDGE;
  SPI_Handler.Init.ClkPolarity       = SPI_POLARITY_LOW;
  SPI_Handler.Init.DataSize          = SPI_DATASIZE_8BIT;
  SPI_Handler.Init.Direction         = SPI_DIRECTION_2LINES;
  SPI_Handler.Init.FirstBit          = SPI_FIRSTBIT_MSB;
  SPI_Handler.Init.SSN               = SPI_SSN_SOFT_LOW;
	
  HAL_SPI_Init(&SPI_Handler);
	
	//SDK������,�����迪��
	LL_BKP_GPIO_SetPinOutputDir(LL_BKP_PIN5);
	LL_BKP_GPIO_SetOutputPin(LL_BKP_PIN5); //����
	
}


void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);
  SPI_Init();
}


void SPI3_Handler(void)
{
  HAL_SPI_IRQHandler(&SPI_Handler);
}



