/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"

#define SPI_MOSI_PIN	GPIO_PIN_10
#define SPI_MISO_PIN	GPIO_PIN_9
#define SPI_SCK_PIN		GPIO_PIN_8
#define SPI_PORT		GPIOA
#define SPIx			SPI3


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

SPI_HandleTypeDef hspi0;
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi2;
SPI_HandleTypeDef hspi3;
void SPI_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct;
  
  GPIO_InitStruct.Pin=SPI_MOSI_PIN|SPI_MISO_PIN|SPI_SCK_PIN;
  GPIO_InitStruct.Alt=GPIO_AF2_SPI3;
  GPIO_InitStruct.PuPd=GPIO_NOPULL;
  HAL_GPIO_Init(SPI_PORT,&GPIO_InitStruct);
  
  hspi3.Instance=SPIx;
  hspi3.Init.BaudRatePrescaler=SPI_BAUDRATEPRESCALER_2;
  hspi3.Init.ClkPhase=SPI_PHASE_1EDGE;
  hspi3.Init.ClkPolarity=SPI_POLARITY_LOW;
  hspi3.Init.DataSize=SPI_DATASIZE_8BIT;
  hspi3.Init.Direction=SPI_DIRECTION_2LINES;
  hspi3.Init.FirstBit=SPI_FIRSTBIT_MSB;
  hspi3.Init.Mode=SPI_MODE_MASTER;
  hspi3.Init.SSN=SPI_SSN_SOFT_LOW;
  HAL_SPI_Init(&hspi3);
}


void HAL_MspInit(void)
{
	SystemClock_Config();
  SPI_Init();
}


void spi_senddata(uint8_t *data,uint16_t len)
{
  HAL_SPI_Transmit(&hspi3,data,len,1000);
}


void SPI0_Handler(void)
{
  HAL_SPI_IRQHandler(&hspi0);
}
void SPI1_Handler(void)
{
  HAL_SPI_IRQHandler(&hspi1);
}
void SPI2_Handler(void)
{
  HAL_SPI_IRQHandler(&hspi2);
}
void SPI3_Handler(void)
{
  HAL_SPI_IRQHandler(&hspi3);
}



