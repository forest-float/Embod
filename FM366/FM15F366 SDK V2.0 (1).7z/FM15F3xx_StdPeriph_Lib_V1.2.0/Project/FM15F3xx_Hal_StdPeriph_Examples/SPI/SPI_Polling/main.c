/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"


int main(void)
{
  uint8_t txbuff[10]={0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A};
  HAL_Init();
	while(1)
	{
    spi_senddata(txbuff,10);
    HAL_Delay(1000);
	}
}
