/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-07-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

/**
  QSPI NAND FLASH DEMO
  1.��ʼ��QSPI�ӿڣ�
  2.��ʼ��NAND FLASH����ȡFLASH ID��
  3.Set NAND FLASH��Write Protection Close��
  4.erase block��
  5.дNAND FLASH��
  6.��NAND FLASH����ȷ�����ݣ�
  */
#define RdWrNum 2048

uint8_t DATA0[2048+64]={0}, DATA1[2048+64]={0};

int main(void)
{
  HAL_Init();
  
  for(int i=0; i<2048;i++)
  {
    DATA0[i] = i;
  }	
  
  printf("QSPI NAND FLASH DEMO\r\n"); 
  
  //��ʼ��NAND FLASH
  if(nand_qspi_flash_init())
    printf("NAND FLASH ERR\n");
  else
    printf("NAND FLASH OK\n");		
  
  //Set NAND FLASH��Write Protection Close
  if(nand_qspi_flash_set_feature(0xA0,0x00))
    printf("Close Write ERR\n");
  
  //erase ��1��block
  if(nand_qspi_flash_block_erase(0x0000040))
    printf("ERASE ERR\n");
  else
    printf("ERASE OK\n");
  
  //дNAND FLASH����1��block����0��Page 
  if(nand_qspi_flash_page_write(0x000040, 0x0000, DATA0, RdWrNum))
    printf("WRITE ERR\n");
  else
    printf("WRITE OK\n");	
  
  //д�꣬��NAND FLASH����1��block����0��Page	
  if(nand_qspi_flash_page_read(0x000040, 0x0000, DATA1, 2048))
    printf("READ ERR\n");
  else
  {
    for(int i =0; i<2048; i++)
    {
      if(DATA0[i] == DATA1[i])
        printf("%04d:%02X; ",i,DATA1[i]);
      else
        printf("%04d:%02X ERR\n",i,DATA1[i]);	
    }
    printf("\nREAD OVER\n");
  }		
  
  while(1)
  {
    LED_Toggle();//��˸LED,��ʾϵͳ��������.
    HAL_Delay(1000);
  }

}
