#ifndef __nand_qspi_flash__
#define __nand_qspi_flash__

//#include "fm15f3xx_hal.h"
//#include "fm15f3xx_conf.h"
#include "board.h"
#include <stdint.h>


// Possible error codes, these are negative to allow
// valid positive return values
enum nand_flash_error {
    FLASH_ERR_OK              =  0,    // No error
    FLASH_ERR_NOT_INITED      = -1,    // Nand QSPI Flash driver not inited
    FLASH_ERR_ALREADY_INITED  = -2,    // Nand QSPI Flash driver already inited
    FLASH_ERR_UNKNOWN_DEVICE  = -3,    // Nand QSPI Flash unsupported device
    FLASH_ERR_READ_ONLY       = -4,    // Device read-only
    FLASH_ERR_BAD_BLOCK       = -5,    // Device read-only
    FLASH_ERR_DATA_TOO_BIG    = -6,    // Data to write/read is greater than page
    FLASH_ERR_ERASE           = -7,    // Block erase hardware error
    FLASH_ERR_PROGRAM         = -8,    // Block write hardware error
    FLASH_ERROR_QSPI          = -100   // Error 
};


// Nand qSpi flash size
uint16_t nand_qspi_flash_page_size(void);

// Nand qSpi Flash block size
uint16_t nand_qspi_flash_block_size(void);

// Nand qSpi Flash blocks count
uint16_t nand_qspi_flash_blocks_count(void);

// Init driver
// @returns 0 on success, negative error code on error
int nand_qspi_flash_init(void);

// Reset flash device
// @returns 0 on success, negative error code on error
int nand_qspi_flash_reset(void);

// Read Nand Flash Status Byte
uint8_t nand_qspi_flash_get_feature(uint8_t Address) ;
int nand_qspi_flash_set_feature(uint8_t Address,uint8_t data);
// Enable write
// @returns 0 on success, negative error code on error
int nand_qspi_flash_write_enable(void);

// Block erase
// @returns 0 on success, negative error code on error
int nand_qspi_flash_block_erase(uint32_t row_address);

// Page read
// @row_address is block_address (first 18 bits) + page_address (6 bits)
// @col_address is the byte address in the page
// @returns number of bytes read or negative error code on error
int nand_qspi_flash_page_read(uint32_t row_address, uint16_t col_address, 
    uint8_t * data, uint16_t read_len);

// Page write
// @row_address is block_address (first 18 bits) + page_address (6 bits)
// @col_address is the byte address in the page
// @returns number of bytes written or negative error code on error
int nand_qspi_flash_page_write(uint32_t row_address, uint16_t col_address, 
    uint8_t * data, uint16_t data_len);



#endif //__nand_qspi_flash__
