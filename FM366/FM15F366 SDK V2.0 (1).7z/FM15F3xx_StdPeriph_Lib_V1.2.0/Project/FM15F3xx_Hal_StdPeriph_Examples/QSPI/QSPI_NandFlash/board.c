/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.DigitFiltEn   = GPIO_DIGITFILTE_OFF;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_LOW;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

//QSPI 初始化
QSPI_HandleTypeDef QSPI_Handle;
void QSPI_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	QSPI_Handle.Instance = QSPI;
	
	QSPI_Handle.Init.WorkMode        = QSPI_WORK_INDIRECT;	  
	QSPI_Handle.Init.AccessFlash     = QSPI_ACCESS_FLASHA;	
	QSPI_Handle.Init.SpeedMode       = QSPI_SPEED_SDR;
	QSPI_Handle.Init.EndianMode      = QSPI_ENDIAN_LITTLE;
	QSPI_Handle.Init.SignificantBit  = QSPI_RxFIFO_MSB;
	QSPI_Handle.Init.IoMode          = QSPI_IO_HIGH;  //在非Quad线模式下，未使用的I/O 拉高
	QSPI_Handle.Init.SampleShift     = QSPI_SAMPLESHIFT_NONE;
	QSPI_Handle.Init.SamplePoint     = QSPI_SAMPLEPOINT_DISABLE;
	QSPI_Handle.Init.ClkMode         = QSPI_CLK_MODE0;
	QSPI_Handle.Init.ClkDiv          = QSPI_CLK_DIV4;  //180M/4=45M，最高通讯速率45M!!!
	QSPI_Handle.Init.RxfifoWm        = 15;
	QSPI_Handle.Init.TxfifoWm        = 0; //此处需要设置成0
	QSPI_Handle.Init.QuitStallCnt    = 0;
	HAL_QSPI_Init(&QSPI_Handle);
	

	//QSPI_D3 --->PC4
	//QSPI_D2 --->PC3
	//QSPI_D1 --->PC2
	//QSPI_D0 --->PC1
	//QSPI_SCK--->PC0
	GPIO_InitStruct.PuPd = GPIO_PULLUP;
	GPIO_InitStruct.Alt  = GPIO_AF5_QSPI;	
	GPIO_InitStruct.Pin  = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_4 ; 
	HAL_GPIO_Init(GPIOC,&GPIO_InitStruct); //该Demo中只使用到数据线D0/D1,
	
	//QSPI_SSN--->PC5 软件控制片选	
	GPIO_InitStruct.Pin           = GPIO_PIN_5;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.DigitFiltEn   = GPIO_DIGITFILTE_OFF;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOC,&GPIO_InitStruct);
	
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);	
	LED_Init();
	QSPI_Init();
}

void LED_Toggle(void)
{
	HAL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}
