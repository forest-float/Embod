#include "nand_qspi_flash.h"


#define QPSI_TIMEOUT_DEFAULT_VALUE  3000
// Device Codes
#define FLAS_DEVICE_XTX_XT26G01x    0x0B
#define FLAS_DEVICE_XT26G01A        0xE1 // 1Gb 

// Nand Flash Commands
#define FLASH_CMD_READ_ID            0x9F
#define FLASH_CMD_GET_FEATURE        0x0F
#define FLASH_CMD_SET_FEATURE        0x1F
#define FLASH_CMD_PAGE_READ          0x13
#define FLASH_CMD_READ_CHACHE        0x03
#define FLASH_CMD_READ_CHACHE2       0x3B
#define FLASH_CMD_READ_CHACHE_DUAL   0xBB
#define FLASH_CMD_RESET              0xFF
#define FLASH_CMD_WRITE_ENABLE       0x06
#define FLASH_CMD_BLOCK_ERASE        0xD8
#define FLASH_CMD_PROGRAM_LOAD       0x02
#define FLASH_CMD_PROGRAM_EXECUTE    0x10

// Nand Flash Status Bits
#define FLASH_OIP_MASK   0x01
#define FLASH_PRG_F_MASK 0x08
#define FLASH_ERS_F_MASK 0x04
#define FLASH_ECC_MASK   0x30
#define FLASH_ECC_BITS   4

// Timings
#define FLASH_PAGE_READ_TIME_US     260
#define FLASH_PAGE_PROGRAM_TIME_US  350 
#define FLASH_BLOCK_ERASE_TIME_MS   3     

// QSPI Send or Recieve Max len
#define QSPI_MAX_LEN                255

// QSPI Flash Select software control PC5
#define QSPI_CS(value) ((value)?(SET_BIT(GPIOC->PSOR,GPIO_PIN_5)):(SET_BIT(GPIOC->PCOR,GPIO_PIN_5))) 

// page size in bytes
static uint16_t flash_page_size = 0;

// block size in pages
static uint16_t flash_block_size = 0;

// blocks count in memory
static uint16_t flash_blocks_count = 0;

//-----------------------------------------------------------------------------
uint16_t nand_qspi_flash_page_size(void) {
  return flash_page_size;
}
uint16_t nand_qspi_flash_block_size(void) {
  return flash_block_size;
}
uint16_t nand_qspi_flash_blocks_count(void) {
  return flash_blocks_count;
}

//-----------------------------------------------------------------------------
int nand_qspi_flash_init(void) 
{
	uint8_t ID[2]={0};
	QSPI_CommandTypeDef cmd;	
	QSPI_CS(0);	
	
	cmd.Instruction      = FLASH_CMD_READ_ID;	
	cmd.InstructionLines = QSPI_LINE_SINGLE;	
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateSize    = QSPI_BYTE_1;
	cmd.AlternateLines   = QSPI_LINE_SINGLE;
	cmd.Alternate        = 0x00;
	cmd.DummyCycles      = 0;
	cmd.DataLines        = QSPI_LINE_SINGLE;
	cmd.NumData          = 2;
	cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
	if(HAL_QSPI_Command(&QSPI_Handle, &cmd, QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
	  return FLASH_ERROR_QSPI;
	if(HAL_QSPI_Receive(&QSPI_Handle, ID, QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
	  return FLASH_ERROR_QSPI;
	
	QSPI_CS(1);	
  // identify device
  if(ID[0] == FLAS_DEVICE_XTX_XT26G01x)
	{ // XTX
    if(ID[1] == FLAS_DEVICE_XT26G01A)
		{ // XT26G01A
      flash_page_size    = 2048+64;
      flash_block_size   = 64;
      flash_blocks_count = 1024;
    } else{
      return FLASH_ERR_UNKNOWN_DEVICE;
    }
  }
	else
	{
    return FLASH_ERR_UNKNOWN_DEVICE;
  }
	
  return FLASH_ERR_OK;
}

//-----------------------------------------------------------------------------
uint8_t nand_qspi_flash_get_feature(uint8_t Address) 
{
  uint8_t Status = FLASH_OIP_MASK;	
  QSPI_CommandTypeDef cmd;
	QSPI_CS(0);
  
  cmd.Instruction      = FLASH_CMD_GET_FEATURE;
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = Address;
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_1;
  cmd.DummyCycles      = 0;
  cmd.AlternateLines   = QSPI_LINE_NONE;
  cmd.DataLines        = QSPI_LINE_SINGLE;
  cmd.NumData          = 1;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  while(Status & FLASH_OIP_MASK)
  {
    delay_us(FLASH_PAGE_READ_TIME_US);
    HAL_QSPI_Command(&QSPI_Handle, &cmd, QPSI_TIMEOUT_DEFAULT_VALUE);
    HAL_QSPI_Receive(&QSPI_Handle, &Status, QPSI_TIMEOUT_DEFAULT_VALUE);	
  }
	QSPI_CS(1);
  return Status;
}
//-----------------------------------------------------------------------------
int nand_qspi_flash_set_feature(uint8_t Address,uint8_t data) 
{
  QSPI_CommandTypeDef cmd;
	QSPI_CS(0);
  
  cmd.Instruction      = FLASH_CMD_SET_FEATURE;
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = Address;
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_1;
  cmd.DummyCycles      = 0;
  cmd.AlternateLines   = QSPI_LINE_NONE;
  cmd.DataLines        = QSPI_LINE_SINGLE;
  cmd.NumData          = 1;
  cmd.TxOrRxData       = QSPI_INDIRECT_TxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
  if(HAL_QSPI_Transmit(&QSPI_Handle,&data,QPSI_TIMEOUT_DEFAULT_VALUE)!= HAL_OK)	
    return FLASH_ERROR_QSPI; 
	
	QSPI_CS(1);
  return FLASH_ERR_OK;
}
//-----------------------------------------------------------------------------
int nand_qspi_flash_reset(void) 
{
  QSPI_CommandTypeDef cmd;	
	QSPI_CS(0);  
  // reset device 
  cmd.Instruction      = FLASH_CMD_RESET;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.AddressLines     = QSPI_LINE_NONE;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_NONE;
  cmd.NumData          = 0;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
	QSPI_CS(1);
  
  // check status
  nand_qspi_flash_get_feature(0xC0);
	
  return FLASH_ERR_OK;
}



//-----------------------------------------------------------------------------
int nand_qspi_flash_write_enable(void) 
{
  QSPI_CommandTypeDef cmd;	
	QSPI_CS(0);
  
  // Enable write 
  cmd.Instruction      = FLASH_CMD_WRITE_ENABLE;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.AddressLines     = QSPI_LINE_NONE;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_NONE;
  cmd.NumData          = 0;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
	QSPI_CS(1);  	
  return FLASH_ERR_OK;
}


//-----------------------------------------------------------------------------
int nand_qspi_flash_block_erase(uint32_t row_address) 
{
  // write enable
  if (nand_qspi_flash_write_enable() != 0)
    return FLASH_ERROR_QSPI;

  // erase block
  QSPI_CommandTypeDef cmd;		
	QSPI_CS(0);
  
  cmd.Instruction      = FLASH_CMD_BLOCK_ERASE;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = row_address;		
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_3;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_NONE;
  cmd.NumData          = 0;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
     return FLASH_ERROR_QSPI;
	
  QSPI_CS(1);
  // check status
  return ((nand_qspi_flash_get_feature(0xC0) & FLASH_ERS_F_MASK) ? FLASH_ERR_ERASE : FLASH_ERR_OK);
}


//-----------------------------------------------------------------------------
//读取NAND Flash的指定页到CACHE
//row_address: 要读取的页(行)地址,范围:0x000000~0x00FFFF
//返回值:0,成功;其他,错误代码
static int nand_qspi_flash_page2cache(uint32_t row_address)
{
  QSPI_CommandTypeDef cmd;		
	QSPI_CS(0);
  // read page to nand cache buffer 
  cmd.Instruction      = FLASH_CMD_PAGE_READ;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = row_address;		
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_3;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_NONE;
  cmd.NumData          = 0;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle, &cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
	QSPI_CS(1);  
  // check status
  if(nand_qspi_flash_get_feature(0xC0) & FLASH_ECC_MASK)
    return FLASH_ERR_BAD_BLOCK;
	
  return FLASH_ERR_OK;
}

//读取NAND Flash的指定Cache内数据
//col_address: 要读取的列开始地址(页内地址),范围:0x000~0x840
//*buffer:     指向数据存储区
//read_len:    读取字节数(不能跨页读),范围:0~255
//返回值:0,成功;其他,错误代码
static int nand_qspi_flash_cache2buffer(uint16_t col_address, uint8_t * buffer, uint8_t read_len)
{
  QSPI_CommandTypeDef cmd;		
  // check data len
  if(read_len + col_address > flash_page_size){
    return FLASH_ERR_DATA_TOO_BIG;
  }
	QSPI_CS(0);
	
  // read buffer from cache
  cmd.Instruction      = FLASH_CMD_READ_CHACHE_DUAL;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = col_address;	
  cmd.AddressLines     = QSPI_LINE_DUAL;
  cmd.AddressSize      = QSPI_BYTE_2;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 4;
  cmd.DataLines        = QSPI_LINE_DUAL;
  cmd.NumData          = read_len;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;	
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
	
  if(HAL_QSPI_Receive(&QSPI_Handle,buffer,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)
    return FLASH_ERROR_QSPI;
	
	QSPI_CS(1);
  return FLASH_ERR_OK;
}

//读取NAND Flash的指定页指定列的数据(main区和spare区都可以使用此函数)
//row_address: 要读取的页(行)地址,范围:0x000000~0x00FFFF
//col_address: 要读取的列开始地址(页内地址),范围:0x000~0x840
//*buffer:     指向数据存储区
//read_len:    读取字节数(不能跨页读),范围:0~2112
//返回值:0,成功;其他,错误代码
int nand_qspi_flash_page_read(uint32_t row_address, uint16_t col_address, uint8_t *buffer, uint16_t read_len)
{
	uint16_t pagereoff;

  if(read_len + col_address > flash_page_size) {
    return FLASH_ERR_DATA_TOO_BIG;
  }
	
	if(read_len <= QSPI_MAX_LEN) pagereoff = read_len; //不大于255个字节
	else pagereoff = QSPI_MAX_LEN;
	
	//read page to cache
	if(nand_qspi_flash_page2cache(row_address) != FLASH_ERR_OK)	
		 return FLASH_ERROR_QSPI;	
	
	//read from cache
	while(1)
	{
    if(nand_qspi_flash_cache2buffer(col_address, buffer, pagereoff) != FLASH_ERR_OK)
      return FLASH_ERROR_QSPI;	
		if(read_len==pagereoff) break;//读取结束了
	 	else //NumByteToWrite>pageremain
		{
			buffer      += pagereoff;
			col_address += pagereoff;
			read_len    -= pagereoff;		//减去已经读取的字节数
			if(read_len > QSPI_MAX_LEN) pagereoff = QSPI_MAX_LEN;   //一次可以读取255个字节
			else pagereoff = read_len;		  //不够255个字节了
		}
	}
 	return FLASH_ERR_OK;
}


//-----------------------------------------------------------------------------
//在NAND一页中写入指定个字节的数据cache
//col_address: 要写入的列开始地址(页内地址),范围:0x000~0x840
//data:        指向数据存储区
//data_len:    要写入的字节数,范围:0~255,该值不能超过该页剩余字节数！！！
//返回值:0,成功;其他,错误代码
static int nand_qspi_flash_program_load(uint16_t col_address, uint8_t *data, uint8_t data_len)
{
  QSPI_CommandTypeDef cmd;

  // copy buffer to nand cache
  cmd.Instruction      = FLASH_CMD_PROGRAM_LOAD;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = col_address;		
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_2;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_SINGLE;
  cmd.NumData          = data_len;
  cmd.TxOrRxData       = QSPI_INDIRECT_TxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
  if(HAL_QSPI_Transmit(&QSPI_Handle,data,QPSI_TIMEOUT_DEFAULT_VALUE)!= HAL_OK)	
    return FLASH_ERROR_QSPI;  
	
  return FLASH_ERR_OK;
}
//若发送的数据长度大于255，将把大于255的数据以指令+数据的模式发送
//data:        指向数据存储区
//data_len:    要写入的字节数,范围:0~255,该值不能超过该页剩余字节数！！！
//返回值:0,成功;其他,错误代码
static int nand_qspi_flash_program_load2(uint8_t *data, uint8_t data_len)
{
  if(data_len <= 0)	
    return FLASH_ERR_OK;
  QSPI_CommandTypeDef cmd;
	
  // copy buffer to nand cache
  cmd.Instruction      = *data;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;		
  cmd.AddressLines     = QSPI_LINE_NONE;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_SINGLE;
  cmd.NumData          = data_len-1;
  cmd.TxOrRxData       = QSPI_INDIRECT_TxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
  if(data_len-1 > 0)
  {
    if(HAL_QSPI_Transmit(&QSPI_Handle,data+1,QPSI_TIMEOUT_DEFAULT_VALUE)!= HAL_OK)	
      return FLASH_ERROR_QSPI;  
  }
	
  return FLASH_ERR_OK;
}
//在NAND一页中写入指定个字节的数据(main区和spare区都可以使用此函数)
//row_address: 要写入的页(行)地址,范围:0x000000~0x00FFFF
//col_address: 要写入的列开始地址(页内地址),范围:0x000~0x840
//data:        指向数据存储区
//data_len:    要写入的字节数,范围:0~2112,且该值不能超过该页剩余字节数！！！
//返回值:0,成功;其他,错误代码
int nand_qspi_flash_page_write(uint32_t row_address, uint16_t col_address, uint8_t *data, uint16_t data_len)
{
	uint16_t pagereoff;
  QSPI_CommandTypeDef cmd;
  if (data_len + col_address > flash_page_size) {
    return FLASH_ERR_DATA_TOO_BIG;
  }

	QSPI_CS(0);
	if(data_len <= QSPI_MAX_LEN) pagereoff = data_len; //不大于255个字节
	else pagereoff = QSPI_MAX_LEN;
	
	//write to cache	
	if(nand_qspi_flash_program_load(col_address, data, pagereoff) != FLASH_ERR_OK)
		return FLASH_ERROR_QSPI;		
	//write to cache
	while(1)
	{	
		if(data_len == pagereoff) break;//读取结束了
	 	else //NumByteToWrite>pageremain
		{
			data        += pagereoff;
			col_address += pagereoff;
			data_len    -= pagereoff;		//减去已经读取的字节数
			if(data_len > QSPI_MAX_LEN) pagereoff = QSPI_MAX_LEN;   //一次可以读取255个字节
			else pagereoff = data_len;		  //不够255个字节了
		}
		if(nand_qspi_flash_program_load2(data,pagereoff) != FLASH_ERR_OK)
		  return FLASH_ERROR_QSPI;	
	}
	QSPI_CS(1);
  // write enable
  if(nand_qspi_flash_write_enable() != 0)
    return FLASH_ERROR_QSPI;	

	QSPI_CS(0);	
  // program execute
  cmd.Instruction      = FLASH_CMD_PROGRAM_EXECUTE;	
  cmd.InstructionLines = QSPI_LINE_SINGLE;
  cmd.Address          = row_address;		
  cmd.AddressLines     = QSPI_LINE_SINGLE;
  cmd.AddressSize      = QSPI_BYTE_3;
  cmd.AlternateLines   = QSPI_LINE_NONE;	
  cmd.DummyCycles      = 0;
  cmd.DataLines        = QSPI_LINE_NONE;
  cmd.NumData          = 0;
  cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
  if(HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE) != HAL_OK)	
    return FLASH_ERROR_QSPI;
	QSPI_CS(1);	
  return (nand_qspi_flash_get_feature(0xC0) & FLASH_PRG_F_MASK) ? FLASH_ERR_PROGRAM : FLASH_ERR_OK;
}
