/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

#define NotQPI 0
uint8_t DATA0[4096+4]={0},DATA1[4096+4] = {0};

int main(void)
{
	uint8_t id[3] ={0};
	
	HAL_Init();
	
	for(int i=0; i<4100;i++)
	{
		DATA0[i] = i;
	}	
	
	printf("QSPI\r\n"); 
	
	FM25QXX_ReadID(id,0);	
	printf("FLASH ID:"); 	
	for(int i =0; i<3; i++)
	  printf("%02X",id[i]);
	printf("\n");	
	
	//ʹ��Quad״̬
	FM25QXX_EnableQuad(NotQPI);
	
	FM25QXX_Read(DATA1, 0x001000, 4100,NotQPI);	
	printf("FLASH дǰ����:\r\n"); 	
	for(int i =0; i<4100; i++)
	  printf("%02X",DATA1[i]);
	printf("\n\n");	
	
	FM25QXX_Write(DATA0, 0x001000, 4100,NotQPI);
	
	FM25QXX_Read(DATA1, 0x001000, 4100,NotQPI);		
	printf("FLASH д������:\r\n"); 	
	for(int i =0; i<4100; i++)
	  printf("%02X",DATA1[i]);
	printf("\n\n");

	
	while(1)
	{
		LED_Toggle();//��˸LED,��ʾϵͳ��������.
		HAL_Delay(500);
	}
	
}
