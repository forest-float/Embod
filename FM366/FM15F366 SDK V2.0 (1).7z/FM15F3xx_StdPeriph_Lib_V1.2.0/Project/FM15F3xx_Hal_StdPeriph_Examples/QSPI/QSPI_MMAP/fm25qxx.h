#ifndef __QSPI_H
#define __QSPI_H		
#include "fm15f3xx_hal.h"
#include "fm15f3xx_conf.h"
#include "board.h"


void FM25QXX_ReadID(uint8_t *id,uint8_t IsQPI);
uint8_t FM25QXX_ReadStatus(uint8_t Reg,uint8_t IsQPI);
void FM25QXX_WriteStatus(uint8_t * data, uint8_t IsQPI);
void FM25QXX_WriteEnable(uint8_t IsQPI);
void FM25QXX_EnableQuad(uint8_t IsQPI);
void FM25QXX_EnableQPI(void);
void FM25QXX_DisableQPI(void);
void FM25QXX_EraseChip(uint8_t IsQPI);
void FM25QXX_EraseSector(uint32_t Dst_Addr,uint8_t IsQPI);
void FM25QXX_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead, uint8_t IsQPI);
void FM25QXX_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint32_t NumByteToWrite, uint8_t IsQPI);

#endif
