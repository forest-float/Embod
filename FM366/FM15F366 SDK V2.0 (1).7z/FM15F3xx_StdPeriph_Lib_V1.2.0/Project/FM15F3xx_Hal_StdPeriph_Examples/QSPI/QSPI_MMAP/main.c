/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

#define NotQPI 0
#define MMAP_BASE_ADDRESS 0x68000000
uint8_t DATA0[4]={0x66, 0x6D, 0x73, 0x68};

int main(void)
{
	uint8_t id[3] ={0},DATA1[4] = {0}, *p=0;
 	HAL_Init();
	
	
	printf("QSPI\r\n"); 
	
	FM25QXX_ReadID(id,0);	
	printf("FLASH ID:"); 	
	for(int i =0; i<3; i++)
	  printf("%02X",id[i]);
	printf("\n");	
	
	//ʹ��Quad״̬
	FM25QXX_EnableQuad(NotQPI);
	//Indirectģʽ��FLASH��д��������
	FM25QXX_Write(DATA0, 0x001000, 4,NotQPI);
	FM25QXX_Read(DATA1, 0x001000, 4,NotQPI);
	printf("Indirectģʽ��ȡ:");
	for(int i =0; i<4; i++)
	  printf("%02X",DATA1[i]);
	printf("\n");		
	
	//MMAPģʽ��
	QSPI_MMAPInit();
	QSPI_MMAP_SetRead();
	p = (uint8_t *)(MMAP_BASE_ADDRESS|0x001000);
	for(int i =0; i<4; i++)
	  DATA1[i]= *p++;
	printf("MMAPģʽ��ȡ:");		
	for(int i =0; i<4; i++)
	  printf("%02X",DATA1[i]);
	printf("\n");	
	
	while(1)
	{
		LED_Toggle();//��˸LED,��ʾϵͳ��������.
		HAL_Delay(500);
	}
	
}
