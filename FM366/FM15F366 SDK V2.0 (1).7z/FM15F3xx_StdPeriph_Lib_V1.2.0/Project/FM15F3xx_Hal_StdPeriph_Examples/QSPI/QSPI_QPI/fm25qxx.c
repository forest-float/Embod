/**
  ******************************************************************************
  * @file    flash.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-05-26
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#include "fm25qxx.h" 

#define QPSI_TIMEOUT_DEFAULT_VALUE 3000

#define ReadID         0x9F
#define ReadStatus1    0x05
#define ReadStatus2    0x35
#define WriteStatus    0x01
#define WriteEnable    0x06
#define EraseChip      0xC7
#define EraseSector    0x20
#define FastRead       0x0B
#define FastReadQuad   0x6B
#define WritePage      0x02
#define WritePageQuad  0x32
#define EnableQPI      0x38
#define DisableQPI     0xFF

//读Flash ID 
void FM25QXX_ReadID(uint8_t *id,uint8_t IsQPI)
{
	QSPI_CommandTypeDef cmd;
	if(IsQPI)
	{
		cmd.InstructionLines = QSPI_LINE_QUAD;
		cmd.DataLines        = QSPI_LINE_QUAD;
	}
	else
	{
		cmd.InstructionLines = QSPI_LINE_SINGLE;
		cmd.DataLines        = QSPI_LINE_SINGLE;
	}		
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.Instruction      = ReadID;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 3;
	cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	HAL_QSPI_Receive(&QSPI_Handle,id,QPSI_TIMEOUT_DEFAULT_VALUE);
}


//读状态
//reg=1:读状态寄存器1
//reg=2:读状态寄存器2
uint8_t FM25QXX_ReadStatus(uint8_t Reg,uint8_t IsQPI)
{
	uint8_t byte =0;
	QSPI_CommandTypeDef cmd;
	
  switch(Reg)
  {
		case 1:
				cmd.Instruction = ReadStatus1;     //读状态寄存器1指令
				break;
		case 2:
				cmd.Instruction = ReadStatus2;    //读状态寄存器2指令
				break;
  }
	if(IsQPI)
	{
		cmd.InstructionLines = QSPI_LINE_QUAD;
		cmd.DataLines        = QSPI_LINE_QUAD;		
	}
	else
	{
		cmd.InstructionLines = QSPI_LINE_SINGLE;
		cmd.DataLines        = QSPI_LINE_SINGLE;
	}
	
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 1;
	cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	HAL_QSPI_Receive(&QSPI_Handle,&byte,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	return byte;
}

//写状态,包括状态寄存器1和2
void FM25QXX_WriteStatus(uint8_t * data, uint8_t IsQPI)
{
	FM25QXX_WriteEnable(IsQPI);					//SET WEL 	
	
	QSPI_CommandTypeDef cmd;
	if(IsQPI)
	{
		cmd.InstructionLines = QSPI_LINE_QUAD;
		cmd.DataLines        = QSPI_LINE_QUAD;	
	}		
	else
	{
		cmd.InstructionLines = QSPI_LINE_SINGLE;
		cmd.DataLines        = QSPI_LINE_SINGLE;
	}

	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.Instruction      = WriteStatus;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 2;
  cmd.TxOrRxData       = QSPI_INDIRECT_TxDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	HAL_QSPI_Transmit(&QSPI_Handle,data,QPSI_TIMEOUT_DEFAULT_VALUE);
}

//写使能
void FM25QXX_WriteEnable(uint8_t IsQPI)
{
	QSPI_CommandTypeDef cmd;
	if(IsQPI)
		cmd.InstructionLines = QSPI_LINE_QUAD;
	else
	  cmd.InstructionLines = QSPI_LINE_SINGLE;
	
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_NONE;
	cmd.Instruction      = WriteEnable;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 0;
	cmd.TxOrRxData       = QSPI_INDIRECT_NoneDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
}

//使能Quad状态
void FM25QXX_EnableQuad(uint8_t IsQPI)
{
  uint8_t status[2] = {0};
	status[0] = FM25QXX_ReadStatus(1, IsQPI);
	status[1] = FM25QXX_ReadStatus(2, IsQPI);
	status[1] |= 0x2; //Quad Enable

	FM25QXX_WriteEnable(IsQPI);
  FM25QXX_WriteStatus(status,IsQPI);
}

//使能QPI状态
void FM25QXX_EnableQPI(void)
{
	QSPI_CommandTypeDef cmd;
	cmd.InstructionLines = QSPI_LINE_SINGLE;
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_NONE;
	cmd.Instruction      = EnableQPI;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 0;
	cmd.TxOrRxData       = QSPI_INDIRECT_NoneDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
}

//失能QPI状态
void FM25QXX_DisableQPI(void)
{
	QSPI_CommandTypeDef cmd;
	cmd.InstructionLines = QSPI_LINE_QUAD;
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_NONE;
	cmd.Instruction      = DisableQPI;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 0;
	cmd.TxOrRxData       = QSPI_INDIRECT_NoneDATA;
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
}
//擦除整个芯片		  
//等待时间超长32s
void FM25QXX_EraseChip(uint8_t IsQPI)   
{
  FM25QXX_WriteEnable(IsQPI);					//SET WEL 	
	
	QSPI_CommandTypeDef cmd;	
	if(IsQPI)
		cmd.InstructionLines = QSPI_LINE_QUAD;
	else
	  cmd.InstructionLines = QSPI_LINE_SINGLE;
	cmd.AddressLines     = QSPI_LINE_NONE;	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_NONE;
	cmd.Instruction      = EraseChip;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 0;
	cmd.TxOrRxData       = QSPI_INDIRECT_NoneDATA;	
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	while(FM25QXX_ReadStatus(1, IsQPI) & 0x01); //等待FLASH执行结束
} 

//擦除一个扇区
//Dst_Addr:扇区地址 根据实际容量设置
//擦除一个扇区的最少时间:90ms
void FM25QXX_EraseSector(uint32_t Dst_Addr,uint8_t IsQPI)   
{
	int counter;
  FM25QXX_WriteEnable(IsQPI);					//SET WEL 	
	
 	Dst_Addr*=4096;
	QSPI_CommandTypeDef cmd;
	if(IsQPI)
	{
		cmd.InstructionLines = QSPI_LINE_QUAD;
		cmd.AddressLines     = QSPI_LINE_QUAD;		
	}
	else
	{
		cmd.InstructionLines = QSPI_LINE_SINGLE;
		cmd.AddressLines     = QSPI_LINE_SINGLE;
	}	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_NONE;
	cmd.AddressSize      = QSPI_BYTE_3;
	cmd.Instruction      = EraseSector;
	cmd.Address          = Dst_Addr;
	cmd.DummyCycles      = 0;
	cmd.NumData          = 0;
	cmd.TxOrRxData       = QSPI_INDIRECT_NoneDATA;	
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	if(IsQPI)
	{
    counter = (600 * (SystemCoreClock / 1000000U)); //QPI模式, 读取的状态不对，所以做软件延时600us
    while(counter != 0U)
    {
      counter--;
    }
	}

	while(FM25QXX_ReadStatus(1,IsQPI) & 0x01) ; //等待FLASH执行结束
}


//在指定地址开始读取指定长度的数据
//pBuffer:数据存储区
//ReadAddr:开始读取的地址(最大32bit)
//NumByteToRead:要读取的字节数(最大255)
static void FM25QXX_ReadPage(uint8_t* pBuffer,uint32_t ReadAddr,uint8_t NumByteToRead, uint8_t IsQPI)   
{
	QSPI_CommandTypeDef cmd;	
	
	if(IsQPI)
	{
		cmd.InstructionLines = QSPI_LINE_QUAD;
    cmd.AddressLines     = QSPI_LINE_QUAD;
		cmd.Instruction      = FastRead;
		cmd.DummyCycles      = 2;
	}
	else
	{
		cmd.InstructionLines = QSPI_LINE_SINGLE;
    cmd.AddressLines     = QSPI_LINE_SINGLE;
		cmd.Instruction      = FastReadQuad;
		cmd.DummyCycles      = 8;
	}
	cmd.DataLines        = QSPI_LINE_QUAD;
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.AddressSize      = QSPI_BYTE_3;
	
	cmd.Address          = ReadAddr;
	cmd.NumData          = NumByteToRead;
	cmd.TxOrRxData       = QSPI_INDIRECT_RxDATA;	
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	HAL_QSPI_Receive(&QSPI_Handle,pBuffer,QPSI_TIMEOUT_DEFAULT_VALUE);
}
//读取SPI FLASH,仅支持QPI模式  
//在指定地址开始读取指定长度的数据
//pBuffer:数据存储区
//ReadAddr:开始读取的地址(最大32bit)
//NumByteToRead:要读取的字节数
void FM25QXX_Read(uint8_t* pBuffer,uint32_t ReadAddr,uint32_t NumByteToRead, uint8_t IsQPI)   
{
	uint16_t pagereoff;	   
	if(NumByteToRead <= 255) pagereoff = NumByteToRead; //不大于255个字节
	else pagereoff = 255;
	while(1)
	{
		FM25QXX_ReadPage(pBuffer, ReadAddr, pagereoff,IsQPI);
		if(NumByteToRead==pagereoff)break;//读取结束了
	 	else //NumByteToWrite>pageremain
		{
			pBuffer += pagereoff;
			ReadAddr += pagereoff;
			NumByteToRead -= pagereoff;			  //减去已经读取的字节数
			if(NumByteToRead > 255)pagereoff = 255;   //一次可以读取255个字节
			else pagereoff=NumByteToRead;		  //不够255个字节了
		}
	}   
}


//SPI在一页(0~65535)内写入少于255个字节的数据
//在指定地址开始写入最大255字节的数据
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)
//NumByteToWrite:要写入的字节数(最大255),该数不应该超过该页的剩余字节数!!!	 
static void FM25QXX_WritePage(uint8_t* pBuffer,uint32_t WriteAddr,uint8_t NumByteToWrite,uint8_t IsQPI)
{
	FM25QXX_WriteEnable(IsQPI);					//写使能	
	
	QSPI_CommandTypeDef cmd;
	if(IsQPI)
	{
	  cmd.InstructionLines = QSPI_LINE_QUAD;
	  cmd.AddressLines     = QSPI_LINE_QUAD;
    cmd.Instruction      = WritePage;		
	}
	else
	{
	  cmd.InstructionLines = QSPI_LINE_SINGLE;
  	cmd.AddressLines     = QSPI_LINE_SINGLE;
		cmd.Instruction      = WritePageQuad;
	}	
	cmd.AlternateLines   = QSPI_LINE_NONE;
	cmd.DataLines        = QSPI_LINE_QUAD;
	cmd.AddressSize      = QSPI_BYTE_3;
	cmd.DummyCycles      = 0;

	cmd.Address          = WriteAddr;	
	cmd.NumData          = NumByteToWrite;
	cmd.TxOrRxData       = QSPI_INDIRECT_TxDATA;	
	HAL_QSPI_Command(&QSPI_Handle,&cmd,QPSI_TIMEOUT_DEFAULT_VALUE);
	
	HAL_QSPI_Transmit(&QSPI_Handle,pBuffer,QPSI_TIMEOUT_DEFAULT_VALUE);    
  
  while(FM25QXX_ReadStatus(1, IsQPI) & 0x01);
} 

//无检验写SPI FLASH 
//必须确保所写的地址范围内的数据全部为0XFF,否则在非0XFF处写入的数据将失败!
//具有自动换页功能 
//在指定地址开始写入指定长度的数据,但是要确保地址不越界!
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)
//NumByteToWrite:要写入的字节数(最大4096)
//CHECK OK
static void FM25QXX_WriteNoCheck(uint8_t* pBuffer,uint32_t WriteAddr,uint16_t NumByteToWrite, uint8_t IsQPI)   
{ 			 		 
	uint16_t pageremain;	   
	pageremain = 128-WriteAddr%128; //半页剩余的字节数		 	   
	if(NumByteToWrite <= pageremain) pageremain = NumByteToWrite; //不大于128个字节
	while(1)
	{
		FM25QXX_WritePage(pBuffer,WriteAddr,pageremain, IsQPI);
		if(NumByteToWrite == pageremain) break;//写入结束了
	 	else //NumByteToWrite>pageremain
		{
			pBuffer += pageremain;
			WriteAddr += pageremain;
			NumByteToWrite -= pageremain;			  //减去已经写入了的字节数
			if(NumByteToWrite > 128)
				pageremain = 128; //一次可以写入128个字节
			else 
				pageremain = NumByteToWrite; 	  //不够128个字节了
		}
	}   
} 

//写 FLASH  
//在指定地址开始写入指定长度的数据
//该函数带擦除操作!
//pBuffer:数据存储区
//WriteAddr:开始写入的地址(最大32bit)						
//NumByteToWrite:要写入的字节数   
static uint8_t SECTOR_BUFFER[4096];		 
void FM25QXX_Write(uint8_t* pBuffer,uint32_t WriteAddr,uint32_t NumByteToWrite, uint8_t IsQPI)   
{ 
	uint32_t secpos;
	uint16_t secoff, secremain, i;    
	uint8_t * SECTOR;	  
  SECTOR = SECTOR_BUFFER;	     
 	secpos=WriteAddr/4096;//扇区地址  
	secoff=WriteAddr%4096;//在扇区内的偏移
	secremain=4096-secoff;//扇区剩余空间大小   
 	if(NumByteToWrite <= secremain)secremain = NumByteToWrite;//不大于4096个字节
	while(1) 
	{	
		FM25QXX_Read(SECTOR,secpos*4096,4096,IsQPI);//读出整个扇区的内容
		for(i=0; i<secremain; i++)//校验数据
		{
			if(SECTOR[secoff+i]!=0XFF)break;//需要擦除  	  
		}
		
		if(i<secremain)//需要擦除
		{
			FM25QXX_EraseSector(secpos, IsQPI);//擦除这个扇区
			for(i=0; i<secremain; i++)	   //复制
			{
				SECTOR[i+secoff] = pBuffer[i];	  
			}
			
			FM25QXX_WriteNoCheck(SECTOR,secpos*4096,4096, IsQPI);	//写入整个扇区   
		}
		else 
		{
		  FM25QXX_WriteNoCheck(pBuffer,WriteAddr,secremain,IsQPI);//写已经擦除了的,直接写入扇区剩余区间.
		}			
		if(NumByteToWrite == secremain)
		{
			break;//写入结束了
		}
		else//写入未结束
		{
			secpos++;//扇区地址增1
			secoff = 0;//偏移位置为0 	 

		  pBuffer += secremain;  //指针偏移
			WriteAddr += secremain;//写地址偏移	   
		  NumByteToWrite -= secremain;				//字节数递减
			if(NumByteToWrite>4096)secremain = 4096;	//下一个扇区还是写不完
			else secremain = NumByteToWrite;			//下一个扇区可以写完了
		}	 
	}	 
}

/************************ (C) COPYRIGHT FudanMicroelectronics *****END OF FILE****/
