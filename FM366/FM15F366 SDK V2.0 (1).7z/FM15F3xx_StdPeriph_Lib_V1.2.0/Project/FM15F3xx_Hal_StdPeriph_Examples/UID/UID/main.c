/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

int main(void)
{
	uint32_t UID[3] = {0};
	uint32_t UIDXOR = 0;
	
	HAL_Init();

	HAL_GetUID(UID);
	printf("UID:%08X%08X%08X\r\n",UID[0],UID[1],UID[2]);		
	
	UIDXOR = HAL_GetUIDXOR();
	printf("UIDXOR:%08X\r\n",UIDXOR);	
	
	while(1)
	{
		HAL_Delay(1000);
		LED_Toggle();
	}
}
