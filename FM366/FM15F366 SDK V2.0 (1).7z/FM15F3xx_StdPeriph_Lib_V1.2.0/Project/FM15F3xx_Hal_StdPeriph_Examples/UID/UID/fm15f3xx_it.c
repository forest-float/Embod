/** 
  ******************************************************************************
  * @file    fm15f3xx_it.c
  * @author  
  * @version V1.0.0
  * @date    14-November-2017
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @attention
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "fm15f3xx_hal.h" 
#include "fm15f3xx_it.h"

/** @addtogroup FM15f3XX_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief  This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
		(*(( volatile unsigned long *)(0x4001B000))) = 0x00;//��ʹ��
}

/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
//void HardFault_Handler(void)
//{
//  /* Go to infinite loop when Hard Fault exception occurs */
//  while (1)
//  {
//  }
//}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
//void PendSV_Handler(void)
//{
//}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
  HAL_IncTick();
}

/******************************************************************************/
/*                 FM15F3XX Peripherals Interrupt Handlers                       */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_fm15f3xx.s).                                               */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/



#define REG32(addr)     (*(( volatile unsigned long *)(addr)))
        
/************************************************************************/
/*������:Isr_Monitor                                                   */
/*����˵��:��ȫ����жϷ������                                       */
/************************************************************************/      
void MONITOR_Handler(void)
{
}

/************************************************************************/
/*������:Isr_PM                                                   */
/*����˵��:PM�жϷ������                                       */
/************************************************************************/
void PM_Int_Handler(void)
{
}

/************************************************************************/
/*������:Isr_ATIMER_Count                                               */
/*����˵��:ATIMER_Count�жϷ������                                     */
/************************************************************************/
void ATIMER_Count_Handler(void)
{        
}




/************************************************************************/
/*������:GPIOA_Handler                                                  */
/*����˵��:GPIOA_Handler�Ϸ������,����оƬ���ֵ�ƽ�жϼ����ж�         */
/************************************************************************/
void GPIOA_Handler(void)
{
}
void GPIOB_Handler(void)
{

}
void GPIOC_Handler(void)
{

}
void GPIOD_Handler(void)
{

}
void GPIOE_Handler(void)
{

}
void GPIOF_Handler(void)
{

}

//void RTC_Tamper_Handler(void)
//{                            
//}



/************************************************************************/
/*������:I2C0_Handler                                                   */
/*����˵��:I2C0_Handler�Ϸ������                                       */
/************************************************************************/
void I2C0_Handler(void)
{
}
/**
  * @}
  */
/************************************************************************/
/*������:RTC_Time_Handler                                               */
/*����˵��:RTC_Time_Handler�Ϸ������                                   */
/************************************************************************/
void RTC_Time_Handler(void)
{   
}

/**
  * @}
  */
/************************************************************************/
/*������:RTC_Second_Handler                                             */
/*����˵��:RTC_Second_Handler                                           */
/************************************************************************/
void RTC_Second_Handler(void)
{                    
}

/************************************************************************/
/*������:FSMC_Handler                                                   */
/*����˵��:FSMC_Handler                                                 */
/************************************************************************/
void FSMC_Handler(void)
{
}


