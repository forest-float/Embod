/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin=GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);
	LED_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}



