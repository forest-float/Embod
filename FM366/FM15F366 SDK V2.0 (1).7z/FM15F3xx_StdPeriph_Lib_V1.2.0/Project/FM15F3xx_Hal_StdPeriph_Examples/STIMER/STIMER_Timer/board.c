/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

TIM_HandleTypeDef TIM_Handle;
void TIM_Init(void)
{
  HAL_CMU_MoudleClockConfig(CMU_MODULE_STIM0, CMU_STMCLKSRC_IRC16M, CMU_CLKDIV_NONE);	
	
	TIM_Handle.Init.STx           = ST0;
	TIM_Handle.Init.Prescaler     = TIM_WORKCLK_DIV8;	
	TIM_Handle.Init.WorkMode      = TIM_WORKMODE_MODCNT;
  TIM_Handle.Init.CountMode     = TIM_CNTMODE_CONTINUES;
  TIM_Handle.Init.CountPolarity = TIM_CNTPOLARITY_LOW;
  TIM_Handle.Init.AutoReload0   = 2000*100;
	HAL_TIM_Base_Init(&TIM_Handle);
	
	HAL_NVIC_SetPriority(STIMER0_IRQn,2,0U);
	HAL_NVIC_EnableIRQ(STIMER0_IRQn);	
	
	HAL_TIM_Base_Start_IT(&TIM_Handle);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);	
	LED_Init();
	TIM_Init();
}


void STIMER0_Handler(void)
{
	HAL_TIM_IRQHandler(&TIM_Handle);
}

void HAL_TIM_ST0Callback(TIM_HandleTypeDef *htim)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}
