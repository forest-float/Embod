/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

TIM_HandleTypeDef TIM0_Handle;
void TIM0_Init(void)
{
  HAL_CMU_MoudleClockConfig(CMU_MODULE_STIM0, CMU_STMCLKSRC_IRC16M, CMU_CLKDIV_NONE);	
	
	TIM0_Handle.Init.STx           = ST0;
	TIM0_Handle.Init.Prescaler     = TIM_WORKCLK_DIV16;	
	TIM0_Handle.Init.WorkMode      = TIM_WORKMODE_ONEPULSE;
  TIM0_Handle.Init.CountMode     = TIM_CNTMODE_CONTINUES;
  TIM0_Handle.Init.CountPolarity = TIM_CNTPOLARITY_LOW;
  TIM0_Handle.Init.AutoReload0   = 1000*1-1;//1ms
	HAL_TIM_Base_Init(&TIM0_Handle);
}

TIM_HandleTypeDef TIM1_Handle;
void TIM1_Init(void)
{
  HAL_CMU_MoudleClockConfig(CMU_MODULE_STIM1, CMU_STMCLKSRC_IRC16M, CMU_CLKDIV_NONE);	
	
	TIM1_Handle.Init.STx           = ST1;
	TIM1_Handle.Init.Prescaler     = TIM_WORKCLK_DIV16;
	TIM1_Handle.Init.WorkMode      = TIM_WORKMODE_MODCNT;
  TIM1_Handle.Init.CountMode     = TIM_CNTMODE_CONTINUES;
  TIM1_Handle.Init.CountPolarity = TIM_CNTPOLARITY_LOW;
  TIM1_Handle.Init.AutoReload0   = 100-1;//1ms*100
	HAL_TIM_Base_Init(&TIM1_Handle);

}

TIM_HandleTypeDef TIM2_Handle;
void TIM2_Init(void)
{
  HAL_CMU_MoudleClockConfig(CMU_MODULE_STIM2, CMU_STMCLKSRC_IRC16M, CMU_CLKDIV_NONE);	
	
	TIM2_Handle.Init.STx           = ST2;
	TIM2_Handle.Init.Prescaler     = TIM_WORKCLK_DIV16;
	TIM2_Handle.Init.WorkMode      = TIM_WORKMODE_MODCNT;
  TIM2_Handle.Init.CountMode     = TIM_CNTMODE_CONTINUES;
  TIM2_Handle.Init.CountPolarity = TIM_CNTPOLARITY_LOW;
  TIM2_Handle.Init.AutoReload0   = 10-1;//100ms*10
	HAL_TIM_Base_Init(&TIM2_Handle);
	
	HAL_NVIC_SetPriority(STIMER2_IRQn,3,0U);
	HAL_NVIC_EnableIRQ(STIMER2_IRQn);	
}
void TIM_Init(void)
{
	TIM0_Init();
  TIM1_Init();	
	TIM2_Init();
	
  __HAL_TIM_ENABLE_IT(ST2);	
	HAL_TIM_Chain_Start(TIM_CHAIN_0TO2);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);	
	LED_Init();
	TIM_Init();
}


void STIMER2_Handler(void)
{
	HAL_TIM_IRQHandler(&TIM2_Handle);
}
void HAL_TIM_ST2Callback(TIM_HandleTypeDef *htim)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}
