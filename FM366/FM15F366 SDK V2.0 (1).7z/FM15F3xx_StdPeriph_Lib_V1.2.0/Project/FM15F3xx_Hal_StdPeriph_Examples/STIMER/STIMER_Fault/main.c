/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

int main(void)
{
	uint32_t cnt;
	HAL_Init();
	printf("Timer ʵ��"); 		
	while(1)
	{
		if(((0x01)&STIMER->CTRL) ==0)
    {
      cnt = HAL_TIM_GetCountValue(ST0);
			printf("CNT:%d\n",cnt); 
			break;
    }
	}
	while(1)
	{
		
	}
}
