/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

/* Pre-processor Definitions. */
#define BUILD_MONTH_IS_JAN (__DATE__[0] == 'J' && __DATE__[1] == 'a' && __DATE__[2] == 'n')
#define BUILD_MONTH_IS_FEB (__DATE__[0] == 'F')
#define BUILD_MONTH_IS_MAR (__DATE__[0] == 'M' && __DATE__[1] == 'a' && __DATE__[2] == 'r')
#define BUILD_MONTH_IS_APR (__DATE__[0] == 'A' && __DATE__[1] == 'p')
#define BUILD_MONTH_IS_MAY (__DATE__[0] == 'M' && __DATE__[1] == 'a' && __DATE__[2] == 'y')
#define BUILD_MONTH_IS_JUN (__DATE__[0] == 'J' && __DATE__[1] == 'u' && __DATE__[2] == 'n')
#define BUILD_MONTH_IS_JUL (__DATE__[0] == 'J' && __DATE__[1] == 'u' && __DATE__[2] == 'l')
#define BUILD_MONTH_IS_AUG (__DATE__[0] == 'A' && __DATE__[1] == 'u')
#define BUILD_MONTH_IS_SEP (__DATE__[0] == 'S')
#define BUILD_MONTH_IS_OCT (__DATE__[0] == 'O')
#define BUILD_MONTH_IS_NOV (__DATE__[0] == 'N')
#define BUILD_MONTH_IS_DEC (__DATE__[0] == 'D')

#define BUILD_MONTH \
    ( \
        (BUILD_MONTH_IS_JAN) ? 1 : \
        (BUILD_MONTH_IS_FEB) ? 2 : \
        (BUILD_MONTH_IS_MAR) ? 3 : \
        (BUILD_MONTH_IS_APR) ? 4 : \
        (BUILD_MONTH_IS_MAY) ? 5 : \
        (BUILD_MONTH_IS_JUN) ? 6 : \
        (BUILD_MONTH_IS_JUL) ? 7 : \
        (BUILD_MONTH_IS_AUG) ? 8 : \
        (BUILD_MONTH_IS_SEP) ? 9 : \
        (BUILD_MONTH_IS_OCT) ? 16 : \
        (BUILD_MONTH_IS_NOV) ? 17 : \
        (BUILD_MONTH_IS_DEC) ? 18 : \
        /* error default */    0 \
    )

#define BUILD_DAY_CH0 ((__DATE__[4] >= '0') ? (__DATE__[4]) : '0')
#define BUILD_DAY_CH1 (__DATE__[ 5])

#define DATE_COMPILE  (((__DATE__[7] - '0') << 28) \
    | (((unsigned int)(__DATE__[8] - '0')) << 24) \
    | (((unsigned int)(__DATE__[9] - '0')) << 20) \
    | (((unsigned int)(__DATE__[10] - '0')) << 16) \
    | (((unsigned int)(BUILD_MONTH)) << 8) \
    | (((unsigned int)(((__DATE__[4] >= '0') ? (__DATE__[4]) : '0') - '0')) << 4) \
| (((unsigned int)__DATE__[5] - '0')))



const  unsigned char g_revision[12] = "V1.00";
//const  unsigned char g_revision_date[12] = __DATE__;
const  unsigned char g_revision_time[16] = __TIME__;


        

int main(void)
{
	uint16_t	times=0;
	uint32_t * p_ver=(uint32_t*)(28);
  float  ver_hard=(*p_ver>>16)/1000.0f;
  float  ver_soft=(*p_ver&0x0000FFFF)/1000.0f;
	HAL_Init();
	
	printf("FirmWare = %s %x %s\r\n", g_revision, DATE_COMPILE, g_revision_time);//
	printf("HARD VER:        V%.3f\r\nSOFT VER:        V%.3f \r\n", ver_hard , ver_soft); //��ӡ�汾��Ϣ

	while(1)
	{
		times++;
		printf("����ֵ��%d\r\n", times);  
		if(times%10==0)	Led_Toggle();//��˸LED,��ʾϵͳ��������.
		HAL_Delay(1000);
	}
}
