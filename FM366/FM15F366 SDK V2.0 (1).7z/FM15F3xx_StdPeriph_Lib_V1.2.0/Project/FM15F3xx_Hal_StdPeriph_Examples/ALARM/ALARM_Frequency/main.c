/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
/**
   ALARM 频率检测实验
	 1.初始化频率检测；
	 2.初始化LED，提示系统正常运行；
	 3.返回待测频率值；
  */
int main(void)
{
	uint32_t freq=1;
	HAL_Init();
	printf("ALARM 频率检测 实验\n");
	HAL_Delay(3000);
	
	freq = HAL_ALM_FrequencyTest_Start(ALM_BASETIMER_0, ALM_BT_CLK_SYS, ALM_BT_CLK_IRC4M);
	printf("SYS->IRC4M_FreqValue(Hz):%d\n",freq);
	HAL_Delay(3000);
	LED_Toggle();
	
	freq = HAL_ALM_FrequencyTest_Start(ALM_BASETIMER_0, ALM_BT_CLK_OSC, ALM_BT_CLK_IRC4M);		
	printf("OSC->IRC4M_FreqValue(Hz):%d\n",freq);
	HAL_Delay(3000);
	LED_Toggle();	

	freq = HAL_ALM_FrequencyTest_Start(ALM_BASETIMER_0, ALM_BT_CLK_SYS, ALM_BT_CLK_IRC16M);
	printf("SYS->IRC16M_FreqValue(Hz):%d\n",freq);
	HAL_Delay(3000);
	LED_Toggle();
	
	freq = HAL_ALM_FrequencyTest_Start(ALM_BASETIMER_0, ALM_BT_CLK_OSC, ALM_BT_CLK_IRC16M);		
	printf("OSC->IRC16M_FreqValue(Hz):%d\n",freq);
	HAL_Delay(3000);
	LED_Toggle();
	
	while(1)
	{
		HAL_Delay(1000);
		LED_Toggle();		
	}
}
