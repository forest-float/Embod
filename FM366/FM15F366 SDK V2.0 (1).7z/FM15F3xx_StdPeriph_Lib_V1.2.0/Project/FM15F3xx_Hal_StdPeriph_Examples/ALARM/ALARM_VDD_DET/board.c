/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

extern void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) ;

void Alarm_Init(void)
{
	ALM_SensorsTypeDef SENSORSn = {0};	
	ALM_MonitorInitTypeDef MonitorInit={0};
	
	SENSORSn.VddDet = ALM_SENSORS_VDET_ENABLE;
	HAL_ALM_SensorsInit(&SENSORSn);
#if 1	
	//��λ����
	MonitorInit.Monitor  = ALM_MONITOR_GROUPA0_VDDH |ALM_MONITOR_GROUPA0_VDDL;//ALM_MONITOR_GROUPA0_VDDL
	MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
	MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
	MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
	MonitorInit.IntEn    = ALM_MONITOR_INT_DISABLE;   //ALM_MONITOR_INT_ENABLE
	MonitorInit.RstEn    = ALM_MONITOR_RST_ENABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
	MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
	MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;	
	MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;	
  HAL_ALM_ClearAllResetRecord();	
#else
	 //�жϲ���
	MonitorInit.Monitor  = ALM_MONITOR_GROUPA0_VDDH |ALM_MONITOR_GROUPA0_VDDL;//ALM_MONITOR_GROUPA0_VDDL
	MonitorInit.RecordEn = ALM_MONITOR_RCD_ENABLE;
	MonitorInit.Input    = ALM_MONITOR_INPUT_NORMAL;//;
	MonitorInit.DmaEn    = ALM_MONITOR_DMA_DISABLE;
	MonitorInit.IntEn    = ALM_MONITOR_INT_ENABLE;   //ALM_MONITOR_INT_ENABLE;ALM_MONITOR_INT_DISABLE
	MonitorInit.RstEn    = ALM_MONITOR_RST_DISABLE;    //ALM_MONITOR_RST_ENABLE	;ALM_MONITOR_RST_DISABLE
	MonitorInit.Power    = ALM_MONITOR_POWERREST_VDD;
	MonitorInit.Nrst     = ALM_MONITOR_NRST_LOW;	
	MonitorInit.Filter   = ALM_MONITOR_FILTER_ENABLE;		
#endif
  HAL_ALM_ClearAllAlarmAndRecord();
	HAL_ALM_MonitorInit(MONITOR_GROUPA, &MonitorInit);
	LL_ALM_SetVDDL(LL_ALM_VDDL_300V);
	LL_ALM_SetBOR(LL_ALM_BOR_256V);
//	LL_ALM_SetVDDL(LL_ALM_VDDL_210V);
//	LL_ALM_SetBOR(LL_ALM_BOR_160V);
	
}

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}
void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);
	printf("Uart initial OK! \r\n");
	printf("ALM_MONITOR->GROUPA0��0x%08X\r\n", ALM_MONITOR->GROUPA0);
	printf("ALM_RST->RCDA��       0x%08X\r\n", ALM_RST->RCDA);
	printf("ALM_MONITOR->ALMRCDA��0x%08X\r\n", ALM_MONITOR->ALMRCDA);
	
	LED_Init();
  Alarm_Init();
}


void Led_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}


void NMI_Handler(void)
{
	printf("ALM_MONITOR->GROUPA0��0x%08X\r\n", ALM_MONITOR->GROUPA0);
	printf("ALM_MONITOR->ALMRCDA��0x%08X\r\n", ALM_MONITOR->ALMRCDA);
	if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPA, LL_ALM_ALARMRESETA_VDDL))
		printf("LOW VDD Alarm\r\n"); 
	
	if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPA, LL_ALM_ALARMRESETA_VDDH))
		printf("HIGH VDD Alarm!\r\n"); 
	
	HAL_ALM_ClearAllAlarmAndRecord();
}
