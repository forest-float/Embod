/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
#include "fm15f3xx_ll_cmu.h"
int main(void)
{
	uint16_t	times=0;
	HAL_Init();
	while(1)
	{
		times++;
		printf("����ֵ��%d\r\n", times);  
		if(times%10==0)	Led_Toggle();//��˸LED,��ʾϵͳ��������.
		HAL_Delay(1000);
//		printf("LM_SENSORS0->EN��  0x%08X\r\n", ALM_SENSORS0->EN);  
//		printf("LM_SENSORS0->CFG�� 0x%08X\r\n", ALM_SENSORS0->CFG); 
//		printf("ALM_RST->ENGROUPE��0x%08X\r\n", ALM_RST->ENGROUPE);
		printf("ALM_RST->RCDA��       0x%08X\r\n", ALM_RST->RCDA);
		printf("ALM_MONITOR->GROUPA0��0x%08X\r\n", ALM_MONITOR->GROUPA0);
		HAL_ALM_ClearAllResetRecord();
	}
}
