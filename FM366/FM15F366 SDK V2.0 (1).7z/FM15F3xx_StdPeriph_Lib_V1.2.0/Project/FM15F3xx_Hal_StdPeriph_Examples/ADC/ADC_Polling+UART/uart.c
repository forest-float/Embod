/**
  ******************************************************************************
  * @file    uart.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
  
#include  <string.h>

#include "uart.h"
//#include <intrins.h>
//#include <absacc.h>			//XBYTE();
#include <stdio.h>
#include <Stdarg.h>

#define UARTX_IRQn		UART1_IRQn

/**
  * @brief  Get Uart clock
  * @param  None
  * @retval uart vlock
  */
uint32_t LL_Get_UART_Clk(void)
{
    uint32_t clksource = 0;
    uint32_t clkdiv = 0;
    clksource = LL_CMU_GetUARTClkSrc();
    clkdiv = (READ_BIT(CMU->MDLCLKA, CMU_MDLCLKA_UARTDIV)) >> CMU_MDLCLKA_UARTDIV_Pos;

    if (clksource == LL_CMU_UARTCLK_SYSCLK)
        clksource  = SystemCoreClock / (LL_CMU_GetSysClkPrescaler() + 1);
    else if (clksource == LL_CMU_UARTCLK_IOCLK)
    {
#ifdef IO_Clock
        clksource  = IO_Clock;
#endif
    }
    else if (clksource == LL_CMU_UARTCLK_IRC16M)
    {
        clksource  = 16000000;
    }
    else if (clksource == LL_CMU_UARTCLK_OSCCLK)
    {
#ifdef 	OSC_Clock
        clksource  = OSC_Clock;
#endif
    }
    else
        clksource  = 16000000;

    return (clksource  >>  clkdiv);
}



/**
  * @brief  Uart Inti
  * @param  UART_TypeDef *UARTx,uint32_t bound, uint32_t stopbit, uint32_t parity
  * @retval none
  */
void UARTx_Init(UART_TypeDef *UARTx,uint32_t bound, uint32_t stopbit, uint32_t parity)
{
    LL_UART_InitTypeDef UART_InitStruct;
    uint32_t uartclk=0;

    //配置管脚
    if (UARTx == UART0)
    {
        LL_GPIO_SetPinMux(GPIOF, LL_GPIO_PIN_0, LL_GPIO_ALT_3); //uart0_tx
        LL_GPIO_SetPinMux(GPIOF, LL_GPIO_PIN_1, LL_GPIO_ALT_3); //uart0_rx
    }
    else if (UARTx == UART1)
    {
        LL_GPIO_SetPinMux(GPIOF, LL_GPIO_PIN_3, LL_GPIO_ALT_3); //uart1_tx
        LL_GPIO_SetPinMux(GPIOF, LL_GPIO_PIN_4, LL_GPIO_ALT_3); //uart1_rx
    }
    else if (UARTx == UART2)
    {
    }

    LL_UART_DeInit(UARTx);

    LL_UART_SetTransferDir(UARTx, LL_UART_DIRECTION_NONE);
		LL_UART_ClearFlag(UARTx,LL_UART_FLAG_TXDONE);

    LL_CMU_SetUARTClkSrc(LL_CMU_UARTCLK_IRC16M);
    LL_CMU_SetUARTClkPrescaler(LL_CMU_REUSEDIV1_DIV1);

    UART_InitStruct.BaudRate          = bound;
    UART_InitStruct.Pdsel             = parity;
    UART_InitStruct.StopBits          = stopbit;
    UART_InitStruct.SampleFactor      = LL_UART_SAMPLEFACTOR_4 ;
    UART_InitStruct.TransferDirection = LL_UART_DIRECTION_TX_RX;

    uartclk =  LL_Get_UART_Clk();
    LL_UART_Init(UARTx, UART_InitStruct, uartclk);

    LL_UART_ClearAllFlag(UARTx);
    LL_UART_DisableAllINT(UARTx);	
	
    LL_UART_EnableINT(UARTx, LL_UART_RXNEIE);  //rxfifo非空中断
    NVIC_SetPriority(UARTX_IRQn, 1);
    NVIC_EnableIRQ(UARTX_IRQn);
}

/**
  * @brief  Uart Send one Byte
  * @param  UART_TypeDef *UARTx,uint8_t byte
  * @retval none
  */
void SendByte(UART_TypeDef *UARTx,uint8_t byte)
{
    while(LL_UART_IsFull_TxFifo(UARTx));	// tx fifo满
    LL_UART_TransmitData8(UARTx,byte);
}

/**
  * @brief  Uart Send  Bytes
  * @param  UART_TypeDef *UARTx,uint8_t* pSendInfo, uint16_t nSendCount
  * @retval none
  */
void UARTx_SendBytes(UART_TypeDef *UARTx,uint8_t* pSendInfo, uint16_t nSendCount)
{
    uint32_t i;
    
		for(i=0; i<nSendCount; i++)
        SendByte(UARTx,pSendInfo[i]);
    while(!LL_UART_GetFlag(UARTx,UART_STATUS_TXDONE));
}

/**
  * @brief  Uart Send  string
  * @param  UART_TypeDef *UARTx,uint8_t* pSendInfo, uint16_t nSendCount
  * @retval none
  */
void UART_SendString(UART_TypeDef *UARTx,uint8_t *pSendString)
{
	uint8_t *pTemp;
	pTemp = pSendString;
	while(*pTemp)
	{
      SendByte(UARTx,*pTemp++);	
	}	
}
/**
  * @brief  UART0_Handler
  * @param  none
  * @retval none
  */
void UART1_Handler(void)
{
	uint8_t i,t=0;
	uint8_t ReceiveBuff[100]={0};
	uint32_t ReceiveSize=0;
	
    if (LL_UART_GetFlag(UART1, UART_STATUS_RXFIFONE) != RESET)
    {		
			t = LL_UART_GetLengthRxFifo(UART1);			
			if(t>0)
			{
				for(i=0; i<t; i++)
				{
					ReceiveBuff[ReceiveSize] = LL_UART_ReceiveData8(UART1);	
					ReceiveSize++;
				}				
				LL_UART_ClearFlag(UART1,UART_STATUS_RXFIFONE);
				UARTx_SendBytes(UART1,ReceiveBuff,ReceiveSize);
				ReceiveSize = 0;
			}
    }
}

uint8_t *os_hex2asc( uint8_t *Ptd, uint8_t *Pts, uint32_t Lg )
{
    uint8_t *Pt0,*pd,*ps = Pts;
    uint32_t i;
    Pt0 = Ptd ;
	  pd  = Ptd ;
    for (i = 0 ; i < Lg ; i++)
    {
        *pd++ = ( (*ps & 0xF0) >> 4 ) + 0x30 ;
        *pd++ = (*ps++ & 0x0F) + 0x30 ;
    }
    while (Pt0 != pd)
    {
        if (*Pt0 >= 0x3A)
        {
            *Pt0 += 7 ;
        }
        Pt0++;
    }
    return((uint8_t*)Ptd);
}

#define DEBUG_INFO 1
uint8_t  gDEBUG_INFO = DEBUG_INFO;

void Uart_Printf(char *pszFormat,...)                                
{
#if DEBUG_INFO
if(gDEBUG_INFO)	
{
	  char aucBuf[0xFF + 1] = {0};
    va_list arglist;
    va_start(arglist, pszFormat);               

		//int vsprintf(char *string, char *format, va_list param)
		vsprintf(aucBuf, pszFormat, arglist);
		//int _vsnprintf(char* str, size_t size, const char* format, va_list ap);
		//vsnprintf(aucBuf,0xFF, pszFormat, arglist);
    va_end(arglist);    

	  UART_SendString(UART1,(uint8_t *)aucBuf);
}
#endif
}


void Uart_Dump(char *pucTitle, uint8_t *pucIn, uint16_t uLen)
{
#if DEBUG_INFO
if(gDEBUG_INFO)	
{
    uint16_t ucI = uLen;
	  uint8_t aucBuf[0xFF + 1] = {0};
		
    Uart_Printf("%s", pucTitle);
	  os_hex2asc(aucBuf,pucIn,ucI);
		UART_SendString(UART1,aucBuf);			 
    Uart_Printf("\n");
}	
#endif
}




//十进制转换为BCD
void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) 
{ 
	int32_t i; 
	uint32_t temp; 

	for(i = length - 1; i >= 0; i--) 
	{ 
		temp = Dec%100; 
		Bcd[i] = ((temp/10)<<4) + ((temp%10) & 0x0F); 
		Dec /= 100; 
	}  

}






