/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

uint16_t VDDA_VALUE;
extern void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) ;

ADC_HandleTypeDef ADC_Handler;//ADC���
void ADC_Init(void)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf;	
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig;
	GPIO_InitTypeDef GPIO_InitStruct;	
	
	
	//ADC����
//	ADC_Handler.Instance=ADC0;
//	ADC_Handler.Init.ClkSel = ADC_ClkSel_BusClkDIV8;	
	
	LL_CMU_ConfigADCClk(LL_CMU_ADCCLK_IRC16M,LL_CMU_REUSEDIV1_DIV1);
	LL_CMU_IDLE_OpenMoudleClk(LL_CMU_MDCLK_ADC);	
	ADC_Handler.Instance=ADC0;
	ADC_Handler.Init.ClkSel = ADC_CLKSEL_WORKCLKDIV1;	
	
	ADC_Handler.Init.WorkMode = ADC_WORKMODE_FREETRIG;	
	ADC_Handler.Init.ConvertMode = ADC_CONVMODE_ONESHOT;	
	ADC_Handler.Init.ReadyTime = 0;
	ADC_Handler.Init.SampleTime = 96;
	ADC_Handler.Init.AutoSleepEn = ADC_AUTOSLEEP_DISABLE;
	ADC_Handler.Init.VcomEn = ADC_VCOM_DISABLE;	
	HAL_ADC_Init(&ADC_Handler);

	//ADCͨ������
	ADC_ChanConf.Channel = ADC_CHANNEL_0;                          
	ADC_ChanConf.Input = ADC_INSRC_VREF12;     	
	ADC_ChanConf.TrigSrc = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay = 0;
	ADC_ChanConf.DiffEn = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn =ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);       
	
	
	//ADC��������
	ADC_ProcessConfig.Channel    = ADC_CHANNEL_0;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum = ADC_AVGMUN_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue=0;//0x800A;
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);
	
	GPIO_InitStruct.Pin=GPIO_PIN_2;
	GPIO_InitStruct.Alt=GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd=GPIO_PULLDOWN;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);		//PD2 ADC_IN10
}

void ADCChannel_Vref12_Init(uint8_t Channel)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf;
	
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig;
	
	HAL_ADC_Stop(&ADC_Handler); //ADC_CTRL[ADCEN]=0ʱ�ſ������µĲ���
		//ADC��������
	ADC_ProcessConfig.Channel    = Channel;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum = ADC_AVGMUN_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue= 0x800A;     
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);
	
    	
	ADC_ChanConf.Channel    = Channel;                          
	ADC_ChanConf.Input      = ADC_INSRC_VREF12;     	
	ADC_ChanConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay  = 0;
	ADC_ChanConf.DiffEn       = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);        //ͨ������

}

void ADCChannel_PD2_Init(uint8_t Channel)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf;
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig;
	GPIO_InitTypeDef GPIO_InitStruct;	

	GPIO_InitStruct.Pin     = GPIO_PIN_2;
	GPIO_InitStruct.Alt     = GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd    = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);		//PD2 ADC_IN10	
	
	HAL_ADC_Stop(&ADC_Handler); //ADC_CTRL[ADCEN]=0ʱ�ſ������µĲ���
		//ADC��������
	ADC_ProcessConfig.Channel    = Channel;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum = ADC_AVGMUN_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue= 0x800A;     
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);
	
	ADC_ChanConf.Channel    = Channel;                          
	ADC_ChanConf.Input      = ADC_INSRC_ADC10;     	
	ADC_ChanConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay  = 0;
	ADC_ChanConf.DiffEn       = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);        //ͨ������
	

}

void ADCChannel_VDDBKP_Init(uint8_t Channel)//ADCͨ��1��ʹ��ƫ�������
{
	ADC_ChannelConfigTypeDef ADC_ChanConf;
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig;
	
	HAL_ADC_Stop(&ADC_Handler); //ADC_CTRL[ADCEN]=0ʱ�ſ������µĲ���
		//ADC��������
	ADC_ProcessConfig.Channel    = Channel;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum = ADC_AVGMUN_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue= 0x800A;     
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);
	
	ADC_ChanConf.Channel    = Channel;                          
	ADC_ChanConf.Input      = ADC_INSRC_VDDBKP;     	
	ADC_ChanConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay  = 0;
	ADC_ChanConf.DiffEn     = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn  = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);        //ͨ������
}

void ADCChannel_TAMPERSENSOR_Init(uint8_t Channel)
{
	ADC_ChannelConfigTypeDef ADC_ChanConf;
	ADC_DataProcessConfigTypeDef  ADC_ProcessConfig;
	
	HAL_ADC_Stop(&ADC_Handler); //ADC_CTRL[ADCEN]=0ʱ�ſ������µĲ���
		//ADC��������
	ADC_ProcessConfig.Channel    = Channel;
	ADC_ProcessConfig.AverageEn    = ADC_CHxAVERAGE_DISABLE;//DISABLE;ENABLE
	ADC_ProcessConfig.AverageNum   = ADC_AVGMUN_6;
	ADC_ProcessConfig.OffsetEn     = ADC_CHxOFFSET_DISABLE;
	ADC_ProcessConfig.OffsetValue= 0x800A;     
	ADC_ProcessConfig.CompareEn    = ADC_CHxCOMPARE_DISABLE;
	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_ProcessConfig);	
 	
	ADC_ChanConf.Channel    = Channel;                          
	ADC_ChanConf.Input      = ADC_INSRC_TEMPERATURE;     	
	ADC_ChanConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChanConf.TrigDelay  = 0;
	ADC_ChanConf.DiffEn     = ADC_CHxDIFF_DISABLE;
	ADC_ChanConf.TrigInvEn  = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChanConf);        //ͨ������
}

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin=GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	ADC_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

//���ADCֵ
//ch: ͨ��ֵ 0~3��ȡֵ��ΧΪ��ADC_Channel_0~ADC_Channel_3
//����ֵ:ת�����
void VREF12_En(void)   
{
	WRITE_REG(VREF->TRIM,0x08ab+14);//trim vref12
	__HAL_ADC_ENABLE_VREF12();	    //vref12 enable
}

void Get_Vrefh(uint32_t ch)
{
	uint32_t val;
	uint8_t tmp[2] = {0};	
	VREF12_En();
	ADCChannel_Vref12_Init(ch);	
	//for(t=0;t<3;t++)
	{
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC		
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ch, 100))
		{
				return ;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ch);

		VDDA_VALUE = 1200 *4096 / val ;		
		DecToBCD(VDDA_VALUE,tmp,2);
		Uart_Dump("ADCChannel0_VDDA_VALUE ->=",tmp,2);
	}		
	
}

//���ADCֵ
//ch: ͨ��ֵ 0~3��ȡֵ��ΧΪ��ADC_Channel_0~ADC_Channel_3
//����ֵ:ת�����
uint16_t Get_Adc(uint32_t ch)   
{
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC
    HAL_ADC_PollForConversion(&ADC_Handler, ch, 100);      //��ѯת��

	  return (uint16_t)HAL_ADC_GetValue(&ADC_Handler ,ch);  //�������һ��ADC0ת�����
}

#define ADC_VREFH_VALUE  3248
//��ȡָ��ͨ����ת��ֵ��ȡtimes��,Ȼ��ƽ�� 
//times:��ȡ����
//����ֵ:ͨ��ch��times��ת�����ƽ��ֵ
uint16_t Get_Adc_Average(uint32_t ch,uint8_t times)
{
	uint32_t reg_val,val,temp_val=0;
	uint8_t tmp[2] = {0};
	uint8_t t;
	
	VREF12_En();
	ADC_Init();
	//��ȡADC VREFH�ο���ѹ VDD
	Get_Vrefh(ch);  
	
	ADCChannel_PD2_Init(ch);
//		reg_val = READ_REG(ADC0->CHANNEL[0].CFG);
//		Uart_Dump("ADC0->ADC0->CHANNEL0->CFG_VALUE ->=",(uint8_t*)&reg_val,2);			
////		WRITE_REG(ADC0->CHANNEL[0].CFG,  0);
////		reg_val = READ_REG(ADC0->CHANNEL[0].CFG);
////		Uart_Dump("ADC0->ADC0->CHANNEL0->CFG_VALUE ->=",(uint8_t*)&reg_val,2);		
//		reg_val = READ_REG(ADC0->CHANNEL[1].CFG);
//		Uart_Dump("ADC0->ADC0->CHANNEL1->CFG_VALUE ->=",(uint8_t*)&reg_val,2);	
	
	for(t=0;t<3;t++)
	{
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC		
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ch, 100))
		{
			  ADCChannel_PD2_Init(ch);
				return HAL_ERROR;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ch);
		val = VDDA_VALUE * val /4096;
		DecToBCD(val,tmp,2);
		Uart_Dump("ADCChannel0_PD2_PULLUP_VALUE ->=",tmp,2);
	}	
	
  ADCChannel_VDDBKP_Init(ch);		
	for(t=0;t<3;t++)
	{
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC		
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ch, 100))
		{
			  ADCChannel_VDDBKP_Init(ch);	
				return HAL_ERROR;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ch);
		val = 4*VDDA_VALUE * val /4096;
		DecToBCD(val,tmp,2);
		Uart_Dump("ADCChannel0_VDDBKP_VALUE ->=",tmp,2);
	}	
	
	ADCChannel_Vref12_Init(ADC_CHANNEL_1);	
  __HAL_ADC_ENABLE_CHANNEL(&ADC_Handler,ADC_CHANNEL_1);	
	for(t=0;t<3;t++)
	{
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ADC_CHANNEL_1); //����ADC		
				
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ADC_CHANNEL_1, 100))
		{
			  ADCChannel_Vref12_Init(ADC_CHANNEL_1);
				return HAL_ERROR;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ADC_CHANNEL_1);
		val = VDDA_VALUE * val /4096;
		DecToBCD(val,tmp,2);
		Uart_Dump("ADCChannel1_Vref12_VALUE ->=",tmp,2);

	}	

	ADCChannel_TAMPERSENSOR_Init(ch);
	__HAL_ADC_ENABLE_CHANNEL(&ADC_Handler,ch);
	for(t=0;t<3;t++)
	{
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC		
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ch, 100))
		{
			   ADCChannel_TAMPERSENSOR_Init(ch);
				return HAL_ERROR;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ch);
		val = VDDA_VALUE * val /4096;
		DecToBCD(val,tmp,2);
		Uart_Dump("ADCChannel0_TEMPERSENSOR_VALUE ->=",tmp,2);		

	}	


  ADCChannel_Vref12_Init(ch);	
	for(t=0;t<times;t++)
	{
		//HAL_Delay(5);
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC		
		if(HAL_OK !=HAL_ADC_PollForConversion(&ADC_Handler ,ch, 100))
		{	
			ADCChannel_Vref12_Init(ch);
			return HAL_ERROR;
		}		
		val = HAL_ADC_GetValue(&ADC_Handler ,ch);
		temp_val += val;
		val = VDDA_VALUE * val /4096;
		DecToBCD(val,tmp,2);
		Uart_Dump("ADCChannel0_AVGVref12_VALUE ->=",tmp,2);
	}
	
	temp_val = temp_val/times *VDDA_VALUE/4096;
	
	/* Disalbe VREF12 */
  __HAL_ADC_DISABLE_VREF12();		
	HAL_ADC_Stop(&ADC_Handler);
	return temp_val;
} 

