/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"
//����ת����ASC�ַ���
uint8_t uitoa(uint32_t n,uint8_t* s)
{
    uint16_t i=0,j;
    uint16_t len=0;
    uint8_t tmp[7] = {0};

    do
    {
        tmp[i++] = n%10+'0';	//ȡ��һ������
    }
    while((n/=10)>0);		//ɾ��������

    len = i;

    for(j=0; j<len; j++,i--)		//���򴢴�
    {
        s[j] = tmp[i-1];
    }
    return len;
}


int main(void)
{
	uint16_t a = 0;
	uint8_t tmp[8] = {0};
	HAL_Init();
	UARTx_Init(UART1,115200,LL_UART_STOPSEL_1BIT,LL_UART_PDSEL_N_8);	
	Uart_Printf("UART initial! \n");
	while(1)
	{
		HAL_Delay(1000);
		
		LED_Toggle();
		a = Get_Adc_Average(ADC_CHANNEL_0,10);	
		DecToBCD(a,tmp,2);
		Uart_Dump("VREF12   ->=",tmp,2);
		Uart_Printf("\n");
	}
}
