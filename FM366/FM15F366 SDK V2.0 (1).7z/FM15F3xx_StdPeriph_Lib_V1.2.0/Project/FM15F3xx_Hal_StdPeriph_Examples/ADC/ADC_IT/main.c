/**
  ******************************************************************************
  * @file    main.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-04-21
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"
#include "uart.h"

int main(void)
{
	HAL_Init();
	stimer0_init();
	UARTx_Init(UART1,115200,LL_UART_STOPSEL_1BIT,LL_UART_PDSEL_N_8);	
	Uart_Printf("UART initial! \n");
	HAL_Delay(1000);
	Get_StartADC_IT(0);
	while(1)
	{
		HAL_Delay(1000);
		LED_Toggle();
	}
}
