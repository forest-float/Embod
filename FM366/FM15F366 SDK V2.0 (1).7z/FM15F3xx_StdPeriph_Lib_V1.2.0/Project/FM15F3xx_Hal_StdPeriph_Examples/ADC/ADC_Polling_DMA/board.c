/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

DMA_HandleTypeDef DMA_Handle;
void DMA_Init(uint16_t Num)
{	
	
	DMA_Handle.Instance                = DMA;
	DMA_Handle.Init.Channel            = DMA_CHANNEL_0;
	DMA_Handle.Init.TrigSrc            = DMA_TRIG_ADC_FINISH;	//ADC Finish DMA_TRIG_SOFTWARE DMA_TRIG_ADC_FINISH
	
//	DMA_Handle.Init.Tcd.SrcAddress     = 0; //������HAL_DMA_Startʱ������
//	DMA_Handle.Init.Tcd.DstAddress     = 0;
	DMA_Handle.Init.Tcd.SrcDataWidth   = DMA_WIDTH_16BIT;//һ��Cycle���˼����ֽ�
	DMA_Handle.Init.Tcd.DstDataWidth   = DMA_WIDTH_16BIT;	
	DMA_Handle.Init.Tcd.SrcOffset      = 20;//Сѭ���ڣ�ÿ�ΰ��˺�ĵ�ַƫ��������offset�����Դ��ַSrcAddress���в���	
	DMA_Handle.Init.Tcd.DstOffset      = Num*2;//Сѭ���ڣ�ÿ�ΰ��˺�ĵ�ַƫ��������offset�����Ŀ�ĵ�ַDstAddress���в���
	DMA_Handle.Init.Tcd.SrcBurst       = DMA_BURST_SINGLE;//һ�ΰ��˼���Cycle
	DMA_Handle.Init.Tcd.DstBurst       = DMA_BURST_SINGLE;
	DMA_Handle.Init.Tcd.Priority       = DMA_PRIORITY_FIX_0;//�̶����ȼ�0	

  DMA_Handle.Init.MinorLoop.BytesNum   = 4*2;//Сѭ���ֽڴ���
  DMA_Handle.Init.MinorLoop.OffsetMode = DMA_MINORLOOP_OFFSET_DST;//��Сѭ��ƫ�����򿪣���Сѭ������BytesNum��Χ1~1023����Сѭ��ƫ�����رգ���Сѭ������BytesNum��Χ1~2^32-1��
	DMA_Handle.Init.MinorLoop.Offset     = 1*2; //Сѭ��������ַƫ������Դ��ַSrcAddress�ᱻ��offset���в���
	
  DMA_Handle.Init.MajorLoop.Num        = 10;//��ѭ������
  DMA_Handle.Init.MajorLoop.SrcOffset  = 0;//��ѭ��������ַƫ������Դ��ַSrcAddress�ᱻ��offset���в���
  DMA_Handle.Init.MajorLoop.DstOffset  = 0;//��ѭ��������ַƫ������Ŀ�ĵ�ַDstAddress�ᱻ��offset���в���
	
  HAL_DMA_Init(&DMA_Handle);
	
	HAL_NVIC_SetPriority(DMA_Channel0_IRQn,2,0U);
	HAL_NVIC_EnableIRQ(DMA_Channel0_IRQn);	

	HAL_NVIC_SetPriority(DMA_Error_IRQn,2,0U);
	HAL_NVIC_EnableIRQ(DMA_Error_IRQn);	
	
}



ADC_HandleTypeDef ADC_Handler;//ADC���
void ADC_Init(void)
{
	ADC_ChannelConfigTypeDef ADC_ChxConf={0};	
	ADC_DataProcessConfigTypeDef ADC_DataProcessConf={0};
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin	= GPIO_PIN_2;
	GPIO_InitStruct.Alt	= GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd= GPIO_PULLUP;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);		//PD2 ADC_IN10	

	//ADC����
	HAL_CMU_MoudleClockConfig(CMU_MODULE_ADC, CMU_ADCCLKSRC_IRC16M, CMU_CLKDIVGP1_1);

	ADC_Handler.Instance    = ADC0;
	ADC_Handler.Init.ClkSel = ADC_CLKSEL_WORKCLKDIV1;	
	ADC_Handler.Init.WorkMode    = ADC_WORKMODE_POLLING;	//ADC_WorkMode_Polling;ADC_WorkMode_FreeTrig
	ADC_Handler.Init.ConvertMode = ADC_CONVMODE_CONTINUE;	//ADC_CONVMODE_CONTINUE;ADC_CONVMODE_ONESHOT
	ADC_Handler.Init.ReadyTime   = 0;
	ADC_Handler.Init.SampleTime  = 96;
	ADC_Handler.Init.AutoSleepEn = ADC_AUTOSLEEP_DISABLE;
	ADC_Handler.Init.VcomEn      = ADC_VCOM_DISABLE;
	ADC_Handler.Init.PollingNum = 3;//polling 4ch
	HAL_ADC_Init(&ADC_Handler);
	
	//������ѯ����
	LL_ADC_SetPollSequence(ADC0,LL_ADC_POLLSEQUENCE0_CH0|LL_ADC_POLLSEQUENCE1_CH1|LL_ADC_POLLSEQUENCE2_CH2|LL_ADC_POLLSEQUENCE3_CH3);                     
 	//������ѯDelay
	LL_ADC_SetPollDelay(ADC0, 5);	
	
  //ͨ������
	ADC_ChxConf.TrigSrc   = ADC_TRIGSRC_SOFTWARE;
	ADC_ChxConf.TrigDelay = 0;
	ADC_ChxConf.DiffEn    = ADC_CHxDIFF_DISABLE;
	ADC_ChxConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
  //���ݴ�������	   	
	ADC_DataProcessConf.AverageEn     = ADC_CHxAVERAGE_DISABLE;
	ADC_DataProcessConf.OffsetEn      = ADC_CHxOFFSET_DISABLE;
	ADC_DataProcessConf.CompareEn     = ADC_CHxCOMPARE_ENABLE;
	ADC_DataProcessConf.CompareMode   = ADC_CMP_LARGER_CV2;
	ADC_DataProcessConf.CompareValue1 = 0x1000; 
	ADC_DataProcessConf.CompareValue2 = 0x0; 

	//Channel 0
	ADC_DataProcessConf.Channel = ADC_CHANNEL_0;    	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);	
	
	ADC_ChxConf.Channel   = ADC_CHANNEL_0;                          
	ADC_ChxConf.Input     = ADC_INSRC_VDDBKP;   //0.83V
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);
//  __HAL_ADC_ENABLE_DMA(&ADC_Handler, ADC_CHANNEL_0);
 
	//Channel 1
  ADC_DataProcessConf.Channel = ADC_CHANNEL_1;    	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);	
	
	ADC_ChxConf.Channel   = ADC_CHANNEL_1;                          
	ADC_ChxConf.Input     = ADC_INSRC_VREF12;  //1.2V	
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);    
//  __HAL_ADC_ENABLE_DMA(&ADC_Handler, ADC_CHANNEL_1);
	
	//Channel 2
  ADC_DataProcessConf.Channel = ADC_CHANNEL_2;    	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);	
	
	ADC_ChxConf.Channel   = ADC_CHANNEL_2;                          
	ADC_ChxConf.Input     = ADC_INSRC_TEMPERATURE; //0.7V 	
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);    
//  __HAL_ADC_ENABLE_DMA(&ADC_Handler, ADC_CHANNEL_2);
	
	//Channel 3
  ADC_DataProcessConf.Channel = ADC_CHANNEL_3;    	
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);	
	
	ADC_ChxConf.Channel   = ADC_CHANNEL_3;                          
	ADC_ChxConf.Input     = ADC_INSRC_ADC10; //3.3V
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChxConf);    
//	__HAL_ADC_ENABLE_DMA(&ADC_Handler, ADC_CHANNEL_3);
	__HAL_ADC_ENABLE_IT(&ADC_Handler, ADC_CHANNEL_3);
	
		//ʹ���ж�ADC0
	HAL_NVIC_SetPriority(ADC0_IRQn, 10, 0U);
	HAL_NVIC_EnableIRQ(ADC0_IRQn);
}


void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	ADC_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}



uint8_t DMA_Complete = 0;

ADC_Polling_Result Start_ADC_Polling(uint16_t *buffer, uint16_t Num)
{
	ADC_Polling_Result Result;
	DMA_Complete = 0;
	DMA_Init(Num);
	
	HAL_DMA_Start_IT(&DMA_Handle, (uint32_t)&(ADC_Handler.Instance->CHANNEL[0].RESULT), (uint32_t)buffer, DMA_Handle.Init.MajorLoop.Num, DMA_IT_TC);
	/* Start ADC Conversion*/
	HAL_ADC_Start(&ADC_Handler, ADC_CHANNEL_0); //����ADCת��

	Result.result3 = buffer;
	Result.result0 = buffer+Num;
	Result.result1 = buffer+Num*2;
	Result.result2 = buffer+Num*3;
	
	return Result;
} 

void ADC0_Handler(void)
{
	HAL_ADC_IRQHandler(&ADC_Handler, ADC_CHANNEL_3);
}


void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc ,uint32_t channel)
{ 
	HAL_DMA_Trig_SoftWare(&DMA_Handle);
}



void DMA_Channel0_Handler(void)
{
	HAL_DMA_IRQHandler(&DMA_Handle);
}

void DMA_Error_Handler(void)
{
	HAL_DMA_Error_IRQHandler(&DMA_Handle);
}


void HAL_DMA_XferCpltCallback(DMA_HandleTypeDef *hdma)
{
	HAL_ADC_Stop(&ADC_Handler); //ֹͣADC DMA TRIG
//	HAL_ADC_Stop_DMA(&ADC_Handler,ADC_CHANNEL_3); //ֹͣADC DMA TRIG
	DMA_Complete = 1;
}


void HAL_DMA_ErrorCallback(DMA_HandleTypeDef *hdma)
{
	printf("Error Code:%08X\n",hdma->ErrorCode);
}
