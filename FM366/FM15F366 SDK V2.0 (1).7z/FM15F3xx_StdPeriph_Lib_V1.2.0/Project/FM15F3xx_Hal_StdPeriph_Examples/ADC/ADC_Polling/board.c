/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include "uart.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

ADC_HandleTypeDef ADC_Handler;//ADC���
void ADC_Init(void)
{
	ADC_ChannelConfigTypeDef ADC_ChannelConf;	
	ADC_DataProcessConfigTypeDef ADC_DataProcessConf;
	GPIO_InitTypeDef GPIO_InitStruct;	
	
	ADC_Handler.Instance         = ADC0;
	//ADC����ʱ��	
	//ADC_Handler.Init.ClkSel      = ADC_ClkSel_BusClkDIV8;	
		
	LL_CMU_ConfigADCClk(LL_CMU_ADCCLK_IRC16M,LL_CMU_REUSEDIV1_DIV1);
	LL_CMU_IDLE_OpenMoudleClk(LL_CMU_MDCLK_ADC);	
	ADC_Handler.Init.ClkSel = ADC_CLKSEL_WORKCLKDIV1;		
	
	ADC_Handler.Init.WorkMode    = ADC_WORKMODE_FREETRIG;	
	ADC_Handler.Init.ConvertMode = ADC_CONVMODE_ONESHOT;	
	ADC_Handler.Init.ReadyTime   = 0;
	ADC_Handler.Init.SampleTime  = 96;
	ADC_Handler.Init.AutoSleepEn   = ADC_AUTOSLEEP_DISABLE;
	ADC_Handler.Init.VcomEn        = ADC_VCOM_DISABLE;	
	HAL_ADC_Init(&ADC_Handler);

	ADC_ChannelConf.Channel    = ADC_CHANNEL_0;                          
	ADC_ChannelConf.Input      = ADC_INSRC_VDDBKP;    // 	
	ADC_ChannelConf.TrigSrc    = ADC_TRIGSRC_SOFTWARE;
	ADC_ChannelConf.TrigDelay  = 0;
	ADC_ChannelConf.DiffEn       = ADC_CHxDIFF_DISABLE;
	ADC_ChannelConf.TrigInvEn = ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChannelConf);        //ͨ������
	
	ADC_DataProcessConf.Channel       = ADC_CHANNEL_0;    	
	ADC_DataProcessConf.AverageEn       = ADC_CHxAVERAGE_ENABLE;
	ADC_DataProcessConf.AverageNum    = ADC_AVGMUN_4;
	ADC_DataProcessConf.CompareEn       = ADC_CHxCOMPARE_ENABLE;
	ADC_DataProcessConf.CompareMode   = ADC_CMP_LESS_CV1;
	ADC_DataProcessConf.CompareValue1 = 0xFFF; 
	ADC_DataProcessConf.CompareValue2 = 0x0; 
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);
	
	GPIO_InitStruct.Pin   = GPIO_PIN_3;
	GPIO_InitStruct.Alt   = GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd  = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);	
}


void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir           = LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock          = LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType         = LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed         = LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig     = LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	UART_Init(115200);
	ADC_Init();
	
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

//���ADCֵ
//ch: ͨ��ֵ 0~3��ȡֵ��ΧΪ��ADC_Channel_0~ADC_Channel_3
//����ֵ:ת�����
uint16_t Get_Adc(uint8_t ch)   
{
		HAL_ADC_Start(&ADC_Handler, ch); //����ADC
	
    HAL_ADC_PollForConversion(&ADC_Handler, ch, 100);      //��ѯת��
   
	  return (uint16_t)HAL_ADC_GetValue(&ADC_Handler ,ch);  //�������һ��ADC0ת�����
}
//��ȡָ��ͨ����ת��ֵ��ȡtimes��,Ȼ��ƽ�� 
//times:��ȡ����
//����ֵ:ͨ��ch��times��ת�����ƽ��ֵ
uint32_t ADC_VREFH_VALUE = 3300;
uint16_t Get_Adc_Average(uint32_t ch,uint8_t cnt)
{
	uint32_t temp_val=0;
	uint8_t t;

	for(t=0;t<cnt;t++)
	{
		HAL_Delay(5);
		temp_val+=Get_Adc(ch);
	}
	temp_val = 4*temp_val/cnt *ADC_VREFH_VALUE/4096;
	return temp_val;
} 

