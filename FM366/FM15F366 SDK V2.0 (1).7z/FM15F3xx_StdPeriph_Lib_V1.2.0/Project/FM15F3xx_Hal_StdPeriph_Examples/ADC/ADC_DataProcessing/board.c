/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif


ADC_HandleTypeDef ADC_Handler;//ADC���
void ADC_Init(void)
{

	ADC_ChannelConfigTypeDef ADC_ChannelConfig;
	ADC_DataProcessConfigTypeDef ADC_DataProcessConf;	
	GPIO_InitTypeDef GPIO_InitStruct;	
	
	ADC_Handler.Instance=ADC0;
	ADC_Handler.Init.ClkSel = ADC_CLKSEL_BUSCLKDIV8;	
	ADC_Handler.Init.WorkMode = ADC_WORKMODE_FREETRIG;	
	ADC_Handler.Init.ConvertMode = ADC_CONVMODE_ONESHOT;	
	ADC_Handler.Init.ReadyTime = 0x300;
	ADC_Handler.Init.SampleTime = 10;
	ADC_Handler.Init.AutoSleepEn = ADC_AUTOSLEEP_DISABLE;
	ADC_Handler.Init.VcomEn = ADC_VCOM_DISABLE;	
	HAL_ADC_Init(&ADC_Handler);

	ADC_DataProcessConf.Channel = ADC_CHANNEL_0;    	
	ADC_DataProcessConf.AverageEn = ADC_CHxAVERAGE_ENABLE;
	ADC_DataProcessConf.AverageNum = ADC_AVGMUN_4;
	ADC_DataProcessConf.OffsetEn = ADC_CHxOFFSET_ENABLE;
	ADC_DataProcessConf.OffsetValue = 0x8045;		//����ʵ���������ADC VREF12����
  ADC_DataProcessConf.CompareEn = ADC_CHxCOMPARE_DISABLE;
	HAL_ADC_DataProcrssConfig(&ADC_Handler,&ADC_DataProcessConf);
	
	ADC_ChannelConfig.Channel = ADC_CHANNEL_0;                          
	ADC_ChannelConfig.Input = ADC_INSRC_VREF12;
	ADC_ChannelConfig.TrigSrc = ADC_TRIGSRC_SOFTWARE;
	ADC_ChannelConfig.TrigDelay = 0x10;
	ADC_ChannelConfig.DiffEn = ADC_CHxDIFF_DISABLE;
	ADC_ChannelConfig.TrigInvEn =ADC_CHxTRIGINV_DISABLE;
	HAL_ADC_ChannelConfig(&ADC_Handler,&ADC_ChannelConfig);        //ͨ������
	
	GPIO_InitStruct.Pin=GPIO_PIN_3;
	GPIO_InitStruct.Alt=GPIO_AF0_ADC;
	GPIO_InitStruct.PuPd=GPIO_NOPULL;
	HAL_GPIO_Init(GPIOF,&GPIO_InitStruct);		
}


void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin=GPIO_PIN_6;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	LED_Init();
	ADC_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

//��ȡָ��ͨ����ת��ֵ��ȡtimes��,Ȼ��ƽ�� 
//times:��ȡ����
//����ֵ:ͨ��ch��times��ת�����ƽ��ֵ
uint32_t ADC_VREFH_VALUE = 3300;
uint32_t Get_Vrefh_VDD(uint32_t ch,uint8_t cnt)
{
	uint8_t t;

	/* Enalbe VREF12 */
  __HAL_ADC_ENABLE_VREF12();
  /* Check VREF12 stabilization flag */
  while(! __HAL_ADC_VREF12_BG_FLAG());
	
  //��ȡADC VREFH�ο���ѹ VDD
	for(t=0;t<cnt;t++)
	{
		HAL_Delay(5);
		
		/* Open ADC */
		HAL_ADC_Start(&ADC_Handler, ch);
		/* Polling for ADC convert over */
		HAL_ADC_PollForConversion(&ADC_Handler, ch, 100);
	
		ADC_VREFH_VALUE = ADC_VREF12_VALUE * 4095 / HAL_ADC_GetValue(&ADC_Handler, ch);
	}
	
	/* Close ADC */
  HAL_ADC_Stop(&ADC_Handler);	
  /* Disalbe VREF12 */
  __HAL_ADC_DISABLE_VREF12();
	
	return ADC_VREFH_VALUE;
} 

