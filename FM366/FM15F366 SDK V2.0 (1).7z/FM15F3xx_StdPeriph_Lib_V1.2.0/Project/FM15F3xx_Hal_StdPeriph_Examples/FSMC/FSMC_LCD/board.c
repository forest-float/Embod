/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"


#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_LOW;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

FSMC_HandleTypeDef FSMC_Handle;
void FSMC_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	FSMC_TimingConfigTypeDef FSMC_TimingtStruct;
	FSMC_Handle.Instance = FSMC;
	
	FSMC_Handle.NORSRAMInit.AccessMode  = FSMC_ACCESS_MMAP;
	FSMC_Handle.NORSRAMInit.MemoryWidth = FSMC_WIDTH_16;
	FSMC_Handle.NORSRAMInit.NWaitEn     = FSMC_NWAIT_DISABLE;
	FSMC_Handle.NORSRAMInit.NWaitPol    = FSMC_NWAITPOL_LOW;
	FSMC_Handle.NORSRAMInit.ClkEn       = FSMC_CLK_DISABLE;
	HAL_FSMC_NORSRAMInit(&FSMC_Handle);
	
	FSMC_TimingtStruct.AddressSetupTime = 0x01;
	FSMC_TimingtStruct.AddressHoldTime  = 0x00;
	FSMC_TimingtStruct.DataSetupTime    = 0x01;
	FSMC_TimingtStruct.DataHoldTime     = 0x03;
	FSMC_TimingtStruct.BusReadyTime     = 0x00;
	HAL_FSMC_TimingConfig(&FSMC_Handle, &FSMC_TimingtStruct);
	

	GPIO_InitStruct.PuPd = GPIO_NOPULL;
	GPIO_InitStruct.Alt  = GPIO_AF7_FSMC;
	
	//FSMC_D4--->LCD_D12
	//FSMC_D5--->LCD_D13
	//FSMC_D6--->LCD_D14
	//FSMC_D7--->LCD_D15
	//FSMC_A17--->LCD_RS
	GPIO_InitStruct.Pin  = GPIO_PIN_0 | GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3 | GPIO_PIN_13; 
	HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	
	//FSMC_NE--->LCD_CS
	GPIO_InitStruct.Pin  = GPIO_PIN_6; 
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	
	//FSMC_D0--->LCD_D8
	//FSMC_D1--->LCD_D9
	//FSMC_D2--->LCD_D10
	//FSMC_D3--->LCD_D11
	GPIO_InitStruct.Pin  = GPIO_PIN_4 | GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7; 
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
	
	//RST ����
	GPIO_InitStruct.Pin           = GPIO_PIN_9;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_LOW;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOB,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOB,GPIO_PIN_9,GPIO_PIN_SET);
	//���� ����
	GPIO_InitStruct.Pin           = GPIO_PIN_1;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	HAL_GPIO_Init(GPIOD,&GPIO_InitStruct);
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_1,GPIO_PIN_RESET);
	
	HAL_FSMC_START(&FSMC_Handle);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);	
	FSMC_Init();
	HAL_Delay(1000);
	LCD_Init();
	HAL_GPIO_WritePin(GPIOD,GPIO_PIN_1,GPIO_PIN_SET); //���� ����
}

