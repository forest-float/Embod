/**
  ******************************************************************************
  * @file    board.c
  * @author  WYL
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"

#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t* file, uint32_t line)
{ 
	while (1)
	{
	}
}
#endif

void LED_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStruct={0};
	
	GPIO_InitStruct.Pin           = GPIO_PIN_6;
	GPIO_InitStruct.Alt           = GPIO_AF1_GPIO;
	GPIO_InitStruct.Dir           = GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength = GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq           = GPIO_IRQorDMA_DISABLE;
	GPIO_InitStruct.Lock          = GPIO_UNLOCK;
	GPIO_InitStruct.OType         = GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd          = GPIO_PULLUP;
	GPIO_InitStruct.Speed         = GPIO_SLEW_SPEED_HIGH;
	GPIO_InitStruct.WECconfig     = GPIO_WKUP_CLOSED;
	HAL_GPIO_Init(GPIOA,&GPIO_InitStruct);
}

void WDT_ALARM_Init(void)
{
	ALM_MonitorInitTypeDef ALM_MonitorInitStruct;
	
	ALM_MonitorInitStruct.Monitor   = ALM_MONITOR_GROUPC2_WDT;
	ALM_MonitorInitStruct.RecordEn  = ALM_MONITOR_RCD_ENABLE;
  ALM_MonitorInitStruct.Input     = ALM_MONITOR_INPUT_NORMAL;
	ALM_MonitorInitStruct.DmaEn     = ALM_MONITOR_DMA_DISABLE;
	ALM_MonitorInitStruct.IntEn     = ALM_MONITOR_INT_ENABLE;	
	ALM_MonitorInitStruct.RstEn     = ALM_MONITOR_RST_DISABLE;
	ALM_MonitorInitStruct.Power     = ALM_MONITOR_POWERREST_LDO12;
	ALM_MonitorInitStruct.Nrst      = ALM_MONITOR_NRST_LOW;
	ALM_MonitorInitStruct.Filter    = ALM_MONITOR_FILTER_ENABLE;
	
  HAL_ALM_MonitorInit(MONITOR_GROUPC, &ALM_MonitorInitStruct);
}


WDT_HandleTypeDef WDT_Handle;
void WTD_Init(void)
{
	HAL_CMU_MoudleClockConfig(CMU_MODULE_WDT, CMU_WDTCLKSRC_LPO1K, CMU_CLKDIV_NONE);	
	
	WDT_Handle.Instance    = WDT0;
	WDT_Handle.Init.Period = WDT_PERIOD_15;
  HAL_WDT_Init(&WDT_Handle);
	
	WDT_ALARM_Init();
	HAL_WDT_Start(&WDT_Handle);
}

void HAL_MspInit(void)
{
	SystemClock_Config();
	UART_Init(115200);	
	LED_Init();
	WTD_Init();
}


void LED_Toggle(void)
{
	LL_GPIO_TogglePin(GPIOA,GPIO_PIN_6);
}

void NMI_Handler(void)
{
	if(HAL_ALM_IsActiveAlarmRecord(MONITOR_GROUPC, LL_ALM_ALARMRESETC_WDT))
	{
		printf("WDT Alarm Int!\r\n");  	
		HAL_WDT_Refresh(&WDT_Handle);
	}
	HAL_ALM_ClearAllAlarmAndRecord();  
	
}

