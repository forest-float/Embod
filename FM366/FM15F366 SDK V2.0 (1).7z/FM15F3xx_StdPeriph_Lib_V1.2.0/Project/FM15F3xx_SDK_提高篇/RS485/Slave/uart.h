/**
  ******************************************************************************
  * @file    uart.h
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */

#ifndef __UART_H_
#define __UART_H_


#ifdef __cplusplus
 extern "C" {
#endif


#include "fm15f3xx.h"
#include "fm15f3xx_conf.h"


void UARTx_Init(UART_TypeDef *UARTx,uint32_t bound, uint32_t stopbit, uint32_t parity);
void UARTx_SendBytes(UART_TypeDef *UARTx,uint8_t* pSendInfo, uint16_t nSendCount);
void Uart_Printf(char *pszFormat,...);
void Uart_Dump(char *pucTitle, uint8_t *pucIn, uint16_t uLen);	
void DecToBCD(uint32_t Dec, uint8_t *Bcd, uint32_t length) ;	 
#ifdef __cplusplus
}
#endif
#endif
