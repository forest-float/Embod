/**
  ******************************************************************************
  * @file    board.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "board.h"
#include  <string.h>
#include <stdio.h>
#include <Stdarg.h>

#define LED2_PIN	       LL_GPIO_PIN_1
#define LED3_PIN	       LL_GPIO_PIN_2
#define LOWER_POWER_CTR  LL_BKP_PIN5
#define RS485_NRE        LL_BKP_PIN3
#define RS485_DE         LL_BKP_PIN4
#define LED_GPIO	GPIOA

void LED_Init(void)
{
	LL_GPIO_InitTypeDef GPIO_InitStruct;
	
	GPIO_InitStruct.Pin=LED2_PIN|LED3_PIN;
	GPIO_InitStruct.Alt=LL_GPIO_ALT_GPIO;
	GPIO_InitStruct.Dir=LL_GPIO_DIRECTION_OUT;
	GPIO_InitStruct.DriveStrength=LL_GPIO_DRIVES_STRONG;
	GPIO_InitStruct.Irq=LL_GPIO_INTorDMA_DISABLE;
	GPIO_InitStruct.Lock=LL_GPIO_LK_UNLOCK;
	GPIO_InitStruct.OType=LL_GPIO_OUTPUT_NOOPENDRAIN;
	GPIO_InitStruct.PuPd=LL_GPIO_PULL_UP;
	GPIO_InitStruct.Speed=LL_GPIO_SLEWRATE_HIGH;
	GPIO_InitStruct.WECconfig=LL_GPIO_WKUP_CLOSED;
	LL_GPIO_Init(LED_GPIO,&GPIO_InitStruct);
}

void POWER_Init(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(LOWER_POWER_CTR);
	LL_BKP_GPIO_SetOutputPin(LOWER_POWER_CTR);
}

void RS485_Transmitting(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(RS485_NRE);
	LL_BKP_GPIO_SetPinOutputDir(RS485_DE);
	LL_BKP_GPIO_SetOutputPin(RS485_DE);
}

void RS485_Receiving(void)
{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(LOWER_POWER_CTR);
	LL_BKP_GPIO_SetOutputPin(RS485_NRE);
	LL_BKP_GPIO_SetOutputPin(RS485_DE);
	LL_BKP_GPIO_ResetOutputPin(RS485_NRE);
}
void RS485_Shoutdown(void)
	{
	LL_BKP_EnableVmain2Vbat(BKP_VMAIN);
	LL_BKP_GPIO_Enable();
	LL_BKP_GPIO_SetPinOutputDir(RS485_NRE);
	LL_BKP_GPIO_SetPinOutputDir(RS485_DE);
	LL_BKP_GPIO_SetOutputPin(RS485_NRE);
	LL_BKP_GPIO_ResetOutputPin(RS485_NRE);
}
void LED_On(void)
{
	LL_GPIO_ResetOutputPin(LED_GPIO,LED2_PIN |LED3_PIN);
}
void LED_Off(void)
{
	LL_GPIO_SetOutputPin(LED_GPIO,LED2_PIN |LED3_PIN);
}
void LED_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN|LED3_PIN);
}
void LED2_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED2_PIN);
}
void LED3_Toggle(void)
{
	LL_GPIO_TogglePin(LED_GPIO,LED3_PIN);
}





