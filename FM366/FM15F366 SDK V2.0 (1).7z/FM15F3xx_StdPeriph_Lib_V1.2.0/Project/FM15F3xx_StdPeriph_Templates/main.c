﻿/**
  ******************************************************************************
  * @file    main.c
  * @author  SRG
  * @version V1.0.0
  * @date    2020-03-17
  * @brief   
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 FudanMicroelectronics.
  * All rights reserved.</center></h2>
  *
  ******************************************************************************
  */
#include "main.h"
#include "board.h"

void delay_ms(uint32_t ms)
{
	int i,j;
	for(i=0;i<ms;i++)
		for(j=0;j<4000;j++);
}

int main(void)
{
	while(1)
	{
		delay_ms(1000);
	}
}
